let weatherData = null;
let airQualityData = null;
let hourlyChart = null;
let userSettings = {
    apiKey: 'ELBNC7KRNHRYQ8KLL4N7E6H23', 
    units: 'metric', 
    darkMode: false,
    showBadge: true,
    language: 'en',
    locationName: 'Hồ Chí Minh'
};
const defaultApiKey = 'ELBNC7KRNHRYQ8KLL4N7E6H23'; 

const currentTempElement = document.getElementById('current-temp');
const weatherConditionElement = document.getElementById('weather-condition');
const celsiusUnitElement = document.getElementById('celsius-unit');
const fahrenheitUnitElement = document.getElementById('fahrenheit-unit');
const tempHighElement = document.getElementById('temp-high');
const tempLowElement = document.getElementById('temp-low');
const feelsLikeTempElement = document.getElementById('feels-like-temp');
const feelsLikeTempMinElement = document.getElementById('feels-like-temp-min');
const feelsLikeTempMaxElement = document.getElementById('feels-like-temp-max');
const weatherAlertElement = document.getElementById('weather-alert');
const refreshButtonElement = document.getElementById('refresh-button');
const humidityElement = document.getElementById('humidity');
const windSpeedElement = document.getElementById('wind-speed');
const windDirectionElement = document.getElementById('wind-direction');
const sunriseTimeElement = document.getElementById('sunrise-time');
const sunsetTimeElement = document.getElementById('sunset-time');
const pm1Element = document.getElementById('pm1');
const pm2p5Element = document.getElementById('pm2p5');
const pm10Element = document.getElementById('pm10');
const so2Element = document.getElementById('so2');
const no2Element = document.getElementById('no2');
const o3Element = document.getElementById('o3');
const coElement = document.getElementById('co');
const aqiusElement = document.getElementById('aqius');
const aqieurElement = document.getElementById('aqieur');
const updateTimeElement = document.getElementById('update-time');
const unitsSelectorElement = document.getElementById('units-selector');
const settingsButtonElement = document.getElementById('settings-button');
const screenshotButtonElement = document.getElementById('screenshot-button');
const settingsModalElement = document.getElementById('settings-modal');
const closeModalElement = document.querySelector('.close-modal');
const darkModeToggleElement = document.getElementById('dark-mode-toggle');
const showBadgeToggleElement = document.getElementById('show-badge-toggle');
const languageSelectorElement = document.getElementById('language-selector');
const apiKeyInputElement = document.getElementById('api-key-input');
const saveSettingsButtonElement = document.getElementById('save-settings');
const locationInputElement = document.getElementById('location-input');
const uvindexElement = document.getElementById('uvindex');
const uvindexContainerElement = document.querySelector('.uvindex');
const alertNoneImage = document.getElementById('alert-none');
const hourlyChartCanvas = document.getElementById('hourly-chart');

const hourlyIconsPlugin = {
    id: 'hourlyIcons',
    afterDatasetsDraw(chart, args, options) {
        const { ctx } = chart;
        const meta = chart.getDatasetMeta(0);
        const elements = meta.data || [];
        const icons = chart.config.data.datasets[0].icons || [];
        const temps = chart.config.data.datasets[0].data || [];
        const unitSuffix = chart.config.data.datasets[0].unitSuffix || '';

        const iconSize = options.iconSize || 20;
        const iconTopMargin = options.iconTopMargin || 5; 
        const textYOffset = options.textYOffset || 8; 
        const textColor = options.textColor || '#000';
        const textFont = options.textFont || '10px Roboto'; 

        ctx.save();
        ctx.font = textFont;
        ctx.fillStyle = textColor;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom'; 

        elements.forEach((element, index) => {
            if (!element.skip) {
                const vm = element.getProps(['x', 'y']); 
                const tempValue = temps[index];

                if (icons[index] && icons[index].complete && icons[index].naturalHeight !== 0) {
                    const icon = icons[index];
                    const iconX = vm.x - (iconSize / 2); 
                    const iconY = iconTopMargin;        
                    ctx.drawImage(icon, iconX, iconY, iconSize, iconSize);
                }

                if (tempValue !== null) {
                    const tempText = `${Math.round(tempValue)}${unitSuffix}`;
                    const textX = vm.x;
                    const textY = vm.y - textYOffset; 

                    ctx.fillText(tempText, textX, textY);
                }
            }
        });
        ctx.restore();
    }
};

if (typeof Chart !== 'undefined' && !Chart.registry.plugins.get(hourlyIconsPlugin.id)) {
    Chart.register(hourlyIconsPlugin);
}

document.addEventListener('DOMContentLoaded', () => {
    loadSettings();
    setupEventListeners();
});

function loadSettings() {
    chrome.storage.sync.get(['userSettings'], (result) => {
        if (result.userSettings) {
            userSettings = { ...userSettings, ...result.userSettings };
            userSettings.apiKey = userSettings.apiKey || defaultApiKey;
        } else {
            saveSettings();
            if (!userSettings.apiKey) {
                showSettingsModal();
            }
        }
        applySettingsToUI();
        getWeatherData(); 
    });
}

function applySettingsToUI() {
    darkModeToggleElement.checked = userSettings.darkMode;
    showBadgeToggleElement.checked = userSettings.showBadge;
    languageSelectorElement.value = userSettings.language;
    unitsSelectorElement.value = userSettings.units;
    apiKeyInputElement.value = userSettings.apiKey;
    locationInputElement.value = userSettings.locationName;

    celsiusUnitElement.classList.toggle('active', userSettings.units === 'metric');
    fahrenheitUnitElement.classList.toggle('active', userSettings.units === 'us');

    document.body.classList.toggle('dark-mode', userSettings.darkMode);
}

// Show the settings modal
function showSettingsModal() {
    // Pre-fill modal inputs with current settings
    darkModeToggleElement.checked = userSettings.darkMode;
    showBadgeToggleElement.checked = userSettings.showBadge;
    languageSelectorElement.value = userSettings.language;
    apiKeyInputElement.value = userSettings.apiKey;
    locationInputElement.value = userSettings.locationName; // Also update location input here

    settingsModalElement.classList.remove('hidden');
    apiKeyInputElement.focus(); // Focus API key input for convenience
}

function saveSettings() {
    chrome.storage.sync.set({ userSettings }, () => {
        console.log('Settings saved:', userSettings);
    });
}

function setupEventListeners() {
    celsiusUnitElement.addEventListener('click', () => setTemperatureUnit('metric'));
    fahrenheitUnitElement.addEventListener('click', () => setTemperatureUnit('us'));

    locationInputElement.addEventListener('change', (e) => {
        userSettings.locationName = e.target.value;
        saveSettings();
        getWeatherData(); 
    });

    refreshButtonElement.addEventListener('click', getWeatherData);

    unitsSelectorElement.addEventListener('change', (e) => {
        userSettings.units = e.target.value;
        celsiusUnitElement.classList.toggle('active', userSettings.units === 'metric');
        fahrenheitUnitElement.classList.toggle('active', userSettings.units === 'us');
        saveSettings();
        getWeatherData(); 
    });

    settingsButtonElement.addEventListener('click', showSettingsModal);

    closeModalElement.addEventListener('click', () => {
        settingsModalElement.classList.add('hidden');
    });

    settingsModalElement.addEventListener('click', (event) => {
        if (event.target === settingsModalElement) {
            settingsModalElement.classList.add('hidden');
        }
    });

    saveSettingsButtonElement.addEventListener('click', () => {
        const oldDarkMode = userSettings.darkMode;

        userSettings.darkMode = darkModeToggleElement.checked;
        userSettings.showBadge = showBadgeToggleElement.checked;
        userSettings.language = languageSelectorElement.value;
        userSettings.apiKey = apiKeyInputElement.value.trim(); 
        userSettings.locationName = locationInputElement.value.trim(); 

        if (userSettings.darkMode !== oldDarkMode) {
            document.body.classList.toggle('dark-mode', userSettings.darkMode);
            const hourlyContent = document.getElementById('hourly-forecast-content');
            if (hourlyContent?.classList.contains('active')) {
                renderHourlyChart(); 
            }
        }

        saveSettings();
        settingsModalElement.classList.add('hidden');
        getWeatherData(); 

        if (!userSettings.showBadge) {
            clearBadge();
        }
    });

    document.querySelectorAll('.accordion-header').forEach(header => {
        header.addEventListener('click', () => {
            const content = header.nextElementSibling;
            const icon = header.querySelector('.accordion-icon');

            content.classList.toggle('active');
            icon.textContent = content.classList.contains('active') ? '▲' : '▼';

            if (header.id === 'hourly-forecast-header') {
                if (content.classList.contains('active')) {
                    renderHourlyChart(); 
                } else if (hourlyChart) {
                    hourlyChart.destroy();
                    hourlyChart = null;
                }
            }
        });
    });

    screenshotButtonElement.addEventListener('click', () => {
        if (typeof chrome !== 'undefined' && chrome.tabs?.captureVisibleTab) {
            chrome.tabs.captureVisibleTab(null, {}, (image) => {
                if (chrome.runtime.lastError) {
                    console.error("Screenshot error:", chrome.runtime.lastError.message);
                    alert("Could not take screenshot. " + chrome.runtime.lastError.message);
                    return;
                }
                const link = document.createElement('a');
                link.download = 'weatherly_screenshot.png';
                link.href = image; 
                link.click();
            });
        } else {
            alert('Screenshot functionality not available.');
            console.warn('chrome.tabs.captureVisibleTab API unavailable.');
        }
    });
}

function setTemperatureUnit(unit) {
    if (userSettings.units === unit) return; 

    userSettings.units = unit;

    celsiusUnitElement.classList.toggle('active', unit === 'metric');
    fahrenheitUnitElement.classList.toggle('active', unit === 'us');

    unitsSelectorElement.value = unit;

    saveSettings();
    getWeatherData(); 
}

function updateTemperatureDisplay() {
    if (!weatherData) return;

    const { temp, feelslike, uvindex } = weatherData.currentConditions;
    const { tempmax, tempmin, feelslikemax, feelslikemin } = weatherData.days[0];
    const unitSymbol = userSettings.units === 'metric' ? '°C' : '°F';

    currentTempElement.textContent = Math.round(temp);
    feelsLikeTempElement.textContent = `${Math.round(feelslike)}${unitSymbol}`;
    feelsLikeTempMinElement.textContent = `↓ ${Math.round(feelslikemin)}${unitSymbol}`;
    feelsLikeTempMaxElement.textContent = `↑ ${Math.round(feelslikemax)}${unitSymbol}`;
    tempHighElement.textContent = `↑ ${Math.round(tempmax)}${unitSymbol}`;
    tempLowElement.textContent = `↓ ${Math.round(tempmin)}${unitSymbol}`;

    uvindexElement.textContent = uvindex ?? '--'; 
    uvindexContainerElement.classList.remove('uv-low', 'uv-moderate', 'uv-high');
    alertNoneImage.style.display = 'none'; 
    alertNoneImage.src = '';
    alertNoneImage.alt = '';

    if (uvindex === null || typeof uvindex === 'undefined') {
    } else if (uvindex <= 2) {
        uvindexContainerElement.classList.add('uv-low');
    } else if (uvindex <= 5) {
        uvindexContainerElement.classList.add('uv-moderate');
    } else { 
        uvindexContainerElement.classList.add('uv-high');
        alertNoneImage.src = 'image/alert.png';
        alertNoneImage.alt = 'UV Alert';
        alertNoneImage.style.display = 'inline-block';
    }

    updateForecastDisplay();
    const hourlyContent = document.getElementById('hourly-forecast-content');
    if (hourlyContent?.classList.contains('active')) {
        renderHourlyChart(); 
    }
}

function updateForecastDisplay() {
    if (!weatherData || !weatherData.days) return;

    const forecastDays = weatherData.days.slice(0, 7); 

    let overallMinTemp = Infinity;
    let overallMaxTemp = -Infinity;
    forecastDays.forEach(day => {
        overallMinTemp = Math.min(overallMinTemp, day.tempmin);
        overallMaxTemp = Math.max(overallMaxTemp, day.tempmax);
    });

    const overallTempRange = Math.max(1, overallMaxTemp - overallMinTemp);

    forecastDays.forEach((day, index) => {
        const date = new Date(day.datetimeEpoch * 1000);
        const dayOfWeek = (index === 0) ? 'Today' : getDayOfWeek(date); 
        const dayMinTemp = day.tempmin;
        const dayMaxTemp = day.tempmax;

        document.getElementById(`day-${index}`).textContent = dayOfWeek;
        document.getElementById(`icon-${index}`).innerHTML = `<img src="${getWeatherIconUrl(day.icon)}" alt="${day.conditions}">`;
        document.getElementById(`high-${index}`).textContent = `${Math.round(dayMaxTemp)}°`;
        document.getElementById(`low-${index}`).textContent = `${Math.round(dayMinTemp)}°`;

        const dayRange = dayMaxTemp - dayMinTemp;
        const barHeightPercent = Math.max(0, (dayRange / overallTempRange) * 100);
        const barOffsetPercent = Math.max(0, ((dayMinTemp - overallMinTemp) / overallTempRange) * 100);

        const barFillElement = document.getElementById(`bar-${index}`).querySelector('.bar-fill');
        barFillElement.style.height = `${barHeightPercent}%`;
        barFillElement.style.bottom = `${barOffsetPercent}%`;
    });
}

function getWeatherData() {
    if (!userSettings.apiKey) {
        console.error("API Key missing.");
        weatherConditionElement.textContent = 'API Key needed';
        showSettingsModal(); 
        return;
    }

    weatherConditionElement.textContent = 'Loading...';
    const apiKey = userSettings.apiKey;
    const locationQuery = userSettings.locationName.trim();

    const fetchDataForLocation = (loc) => {
        const encodedLoc = encodeURIComponent(loc);
        const weatherUrl = `https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${encodedLoc}?unitGroup=${userSettings.units}&include=days,hours,current,alerts&key=${apiKey}&contentType=json`;
        const airQualityUrl = `https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${encodedLoc}?unitGroup=${userSettings.units}&include=days,hours,current,alerts,airQuality&key=${apiKey}&contentType=json&elements=datetime,pm1,pm2p5,pm10,o3,no2,so2,co,aqius,aqieur`;

        weatherData = null;
        airQualityData = null;

        Promise.all([
            fetch(weatherUrl).then(handleApiResponse),
            fetch(airQualityUrl).then(handleApiResponse)
        ])
        .then(([weatherResult, airQualityResult]) => {
            console.log("Weather Raw:", weatherResult);
            console.log("AQ Raw:", airQualityResult);

            if (weatherResult?.currentConditions && weatherResult.days?.[0]?.hours) {
                weatherData = weatherResult;
                updateTimeElement.textContent = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                if (userSettings.showBadge) {
                    updateBadge();
                }
            } else {
                console.error("Incomplete weather data received:", weatherResult);
                weatherData = null; 
            }

            if (airQualityResult?.currentConditions) {
                airQualityData = airQualityResult;
            } else {
                console.warn("Air quality data missing or incomplete:", airQualityResult);
                airQualityData = null;
            }

            updateUI(); 

            if (!weatherData) {
                weatherConditionElement.textContent = 'Load failed';
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
            weatherConditionElement.textContent = 'Error loading';
            weatherData = null;
            airQualityData = null;
            updateUI();
        });
    };

    if (locationQuery) {
        fetchDataForLocation(locationQuery);
    } else {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    fetchDataForLocation(`${position.coords.latitude},${position.coords.longitude}`);
                },
                (error) => {
                    console.error('Geolocation Error:', error);
                    weatherConditionElement.textContent = 'Location unavailable';
                    userSettings.locationName = 'Hồ Chí Minh'; 
                    locationInputElement.value = userSettings.locationName; 
                    saveSettings(); 
                    fetchDataForLocation(userSettings.locationName);
                },
                { timeout: 10000 } 
            );
        } else {
            console.warn("Geolocation not supported.");
            weatherConditionElement.textContent = 'Location needed';
            userSettings.locationName = 'Hồ Chí Minh'; 
            locationInputElement.value = userSettings.locationName; 
            saveSettings(); 
            fetchDataForLocation(userSettings.locationName);
        }
    }
}

function handleApiResponse(response) {
    if (!response.ok) {
        return response.text().then(text => {
            throw new Error(`API Error ${response.status}: ${text || response.statusText}`);
        });
    }
    return response.text().then(text => {
        try {
            return text ? JSON.parse(text) : null;
        } catch (e) {
            console.error("JSON Parsing Error:", e, "Response Text:", text);
            throw new Error("Failed to parse API response.");
        }
    });
}


function updateUI() {
    if (!weatherData) {
        weatherConditionElement.textContent = (
            weatherConditionElement.textContent.includes('Error') ||
            weatherConditionElement.textContent.includes('failed') ||
            weatherConditionElement.textContent.includes('Loading')
        ) ? weatherConditionElement.textContent : 'No data';

        currentTempElement.textContent = '--';
        humidityElement.textContent = '--%';
        windSpeedElement.textContent = `-- ${userSettings.units === 'metric' ? 'km/h' : 'mph'}`; 
        windDirectionElement.textContent = '--°';
        sunriseTimeElement.textContent = '--:--';
        sunsetTimeElement.textContent = '--:--';
        feelsLikeTempElement.textContent = '--°';
        feelsLikeTempMinElement.textContent = '↓ --°';
        feelsLikeTempMaxElement.textContent = '↑ --°';
        tempHighElement.textContent = '↑ --°';
        tempLowElement.textContent = '↓ --°';
        uvindexElement.textContent = '--';
        uvindexContainerElement.classList.remove('uv-low', 'uv-moderate', 'uv-high');
        alertNoneImage.style.display = 'none';
        weatherAlertElement.classList.add('hidden'); 

        updateAirQualityDisplay(); 
        updateForecastDisplay();  
        if (hourlyChart) {
            hourlyChart.destroy(); 
            hourlyChart = null;
        }
        if (hourlyChartCanvas) {
            const ctx = hourlyChartCanvas.getContext('2d');
            ctx.clearRect(0, 0, hourlyChartCanvas.width, hourlyChartCanvas.height);
            ctx.fillStyle = getComputedStyle(document.body).getPropertyValue('--text-color') || '#333';
            ctx.textAlign = 'center';
            ctx.fillText("Weather data unavailable.", hourlyChartCanvas.width / 2, 50); 
        }

        return; 
    }

    weatherConditionElement.textContent = weatherData.currentConditions.conditions || 'N/A';
    updateTemperatureDisplay(); 

    humidityElement.textContent = `${weatherData.currentConditions.humidity ?? '--'}%`;

    const windSpeedValue = weatherData.currentConditions.windspeed;
    const windSpeedUnit = userSettings.units === 'metric' ? 'km/h' : 'mph';
    windSpeedElement.textContent = (windSpeedValue !== null && typeof windSpeedValue !== 'undefined')
        ? `${Math.round(windSpeedValue)} ${windSpeedUnit}`
        : `-- ${windSpeedUnit}`;

    windDirectionElement.textContent = `${weatherData.currentConditions.winddir ?? '--'}°`;

    if (weatherData.days?.[0]) {
        sunriseTimeElement.textContent = formatTimeFromAPI(weatherData.days[0].sunrise);
        sunsetTimeElement.textContent = formatTimeFromAPI(weatherData.days[0].sunset);
    } else {
        sunriseTimeElement.textContent = '--:--';
        sunsetTimeElement.textContent = '--:--';
    }

    updateAirQualityDisplay(); 

    if (weatherData.alerts?.length > 0) {
        weatherAlertElement.classList.remove('hidden');
        weatherAlertElement.title = weatherData.alerts
            .map(a => a.event || 'Weather Alert')
            .join('; ');
    } else {
        weatherAlertElement.classList.add('hidden');
        weatherAlertElement.title = ''; 
    }

    const hourlyContent = document.getElementById('hourly-forecast-content');
    if (hourlyContent?.classList.contains('active')) {
        renderHourlyChart();
    }
}

function formatTimeFromAPI(timeString) {
    if (!timeString || typeof timeString !== 'string') {
        return '--:--';
    }
    const parts = timeString.split(':');
    return parts.length >= 2 ? `${parts[0]}:${parts[1]}` : timeString;
}

// --- Update Air Quality Display Section ---
function updateAirQualityDisplay() {
    const aqElements = {
        pm1: pm1Element, pm2p5: pm2p5Element, pm10: pm10Element,
        so2: so2Element, no2: no2Element, o3: o3Element, co: coElement,
        aqius: aqiusElement, aqieur: aqieurElement
    };

    const aqUnits = {
        pm1: 'μg/m³', pm2p5: 'μg/m³', pm10: 'μg/m³', so2: 'μg/m³',
        no2: 'μg/m³', o3: 'μg/m³', co: 'μg/m³', aqius: '', aqieur: ''
    };

    const aqThresholds = {
        pm2p5: { good: 12, moderate: 35.4, unhealthy_sens: 55.4, unhealthy: 150.4, very_unhealthy: 250.4 },
        pm10: { good: 54, moderate: 154, unhealthy_sens: 254, unhealthy: 354, very_unhealthy: 424 },
        aqius: { good: 50, moderate: 100, unhealthy_sens: 150, unhealthy: 200, very_unhealthy: 300 },
        aqieur: { good: 50, moderate: 100, unhealthy_sens: 150, unhealthy: 200, very_unhealthy: 300 }, 
        o3: { good: 106, moderate: 137, unhealthy_sens: 167, unhealthy: 206, very_unhealthy: 392 },
        no2: { good: 100, moderate: 188, unhealthy_sens: 677, unhealthy: 1220, very_unhealthy: 2349 },
        so2: { good: 92, moderate: 197, unhealthy_sens: 485, unhealthy: 797, very_unhealthy: 1583 },
        co: { good: 4400, moderate: 9400, unhealthy_sens: 12400, unhealthy: 15400, very_unhealthy: 30400 } 
    };

    const aqPrecision = {
        pm1: 1, pm2p5: 1, pm10: 0, so2: 1, no2: 1, o3: 1, co: 0, aqius: 0, aqieur: 0
    };

    const aqConditions = airQualityData?.currentConditions;

    const setAirQualityValue = (element, value, unit = '', thresholds = null, precision = 0) => {
        if (value === null || typeof value === 'undefined') {
            element.textContent = `-- ${unit}`.trim();
            element.style.color = 'var(--text-color)';
            element.style.opacity = '0.6'; 
        } else {
            const numericValue = Number(value);
            element.textContent = `${numericValue.toFixed(precision)} ${unit}`.trim();
            element.style.opacity = '1';

            if (thresholds) {
                if (numericValue <= thresholds.good) element.style.color = '#4caf50'; // Green
                else if (numericValue <= thresholds.moderate) element.style.color = '#ffeb3b'; // Yellow
                else if (numericValue <= thresholds.unhealthy_sens) element.style.color = '#ff9800'; // Orange
                else if (numericValue <= thresholds.unhealthy) element.style.color = '#f44336'; // Red
                else if (numericValue <= thresholds.very_unhealthy) element.style.color = '#9c27b0'; // Purple
                else element.style.color = '#795548'; 
            } else {
                element.style.color = 'var(--text-color)';
            }
        }
    };

    for (const key in aqElements) {
        if (Object.hasOwnProperty.call(aqElements, key)) {
            setAirQualityValue(
                aqElements[key],           
                aqConditions?.[key],       
                aqUnits[key],               
                aqThresholds[key],          
                aqPrecision[key]           
            );
        }
    }
}


async function renderHourlyChart() {
    if (!weatherData?.days?.[0]?.hours || !hourlyChartCanvas) {
        console.error("Hourly data or canvas element unavailable for chart rendering.");
        if (hourlyChartCanvas) {
            const ctx = hourlyChartCanvas.getContext('2d');
            ctx.clearRect(0, 0, hourlyChartCanvas.width, hourlyChartCanvas.height);
            ctx.fillStyle = getComputedStyle(document.body).getPropertyValue('--text-color') || '#333';
            ctx.textAlign = 'center';
            ctx.fillText("Hourly data not available.", hourlyChartCanvas.width / 2, hourlyChartCanvas.height / 2);
        }
        return;
    }

    const hourlyData = weatherData.days[0].hours;
    const labels = [];         
    const temperatures = [];  
    const icons = [];          

    for (let i = 0; i < 24; i++) {
        const hourString = i.toString().padStart(2, '0') + ":00"; 
        labels.push(hourString);

        const hourEntry = hourlyData.find(h => h.datetime.startsWith(hourString));

        if (hourEntry) {
            temperatures.push(hourEntry.temp);
            const img = new Image();
            img.src = getWeatherIconUrl(hourEntry.icon); 
            icons.push(img);
        } else {
            temperatures.push(null);
            const img = new Image();
            icons.push(img);
        }
    }

    try {
        await Promise.all(icons.map(img => {
            if (img.complete || !img.src) {
                return Promise.resolve();
            }
            return new Promise((resolve) => {
                img.onload = resolve;
                img.onerror = () => {
                    console.warn(`Icon failed to load: ${img.src}`);
                    resolve(); 
                };
            });
        }));
    } catch (error) {
        console.error("Error preloading hourly icons:", error);
    }


    const ctx = hourlyChartCanvas.getContext('2d');
    const unitSuffix = userSettings.units === 'metric' ? '°C' : '°F';

    const bodyStyle = getComputedStyle(document.body);
    const primaryColor = bodyStyle.getPropertyValue('--primary-color').trim() || '#36b6e5'; 
    const textColor = bodyStyle.getPropertyValue('--text-color').trim() || '#333';        
    const gridColor = (bodyStyle.getPropertyValue('--border-color').trim() || '#e0e0e0') + '80';

    if (hourlyChart) {
        hourlyChart.destroy();
        hourlyChart = null;
    }

    // Create the new Chart instance
    hourlyChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: `Temperature (${unitSuffix})`,
                data: temperatures,
                borderColor: primaryColor,
                backgroundColor: primaryColor + '33', 
                tension: 0.3,      
                fill: false,      
                pointRadius: 3,
                pointHoverRadius: 5,
                pointBackgroundColor: primaryColor,
                icons: icons,      
                unitSuffix: unitSuffix, 
                segment: {
                    borderColor: ctx => (temperatures[ctx.p0DataIndex] === null || temperatures[ctx.p1DataIndex] === null) ? gridColor : undefined, // Use grid color for dashed segments
                    borderDash: ctx => (temperatures[ctx.p0DataIndex] === null || temperatures[ctx.p1DataIndex] === null) ? [6, 6] : undefined, // Dash pattern [line, gap]
                },
                spanGaps: false 
                // --- End gap styling ---
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: {
                    top: 35 
                }
            },
            plugins: {
                hourlyIcons: {
                    iconSize: 22,      
                    iconTopMargin: 5,  
                    textYOffset: -7,    
                    textColor: textColor,
                    textFont: '11px Roboto' 
                },
                legend: {
                    display: false 
                },
                tooltip: {
                    callbacks: {
                        title: (tooltipItems) => tooltipItems[0].label,
                        label: (tooltipItem) => {
                            let label = tooltipItem.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (tooltipItem.parsed.y !== null) {
                                label += `${tooltipItem.parsed.y.toFixed(1)} ${unitSuffix}`;
                            } else {
                                label += 'No data';
                            }
                            return label;
                        }
                    },
                    bodyColor: textColor,
                    titleColor: textColor,
                    backgroundColor: bodyStyle.getPropertyValue('--card-color').trim() || '#fff',
                    borderColor: primaryColor,
                    borderWidth: 1,
                    padding: 8,
                    displayColors: false 
                }
            },
            scales: {
                x: {
                    title: {
                        display: false 
                    },
                    ticks: {
                        color: textColor, 
                        maxRotation: 0,   
                        autoSkip: false,  
                        minRotation: 0    
                    },
                    grid: {
                        color: gridColor 
                    }
                 },
                y: {
                    title: {
                        display: false 
                    },
                    ticks: {
                        color: textColor,
                        callback: (value) => Math.round(value) + unitSuffix
                    },
                    grid: {
                        color: gridColor
                    },
                    beginAtZero: false 
                }
            },
            interaction: {
                intersect: false, 
                mode: 'index'    
            }
        }
    });
}
// --- End renderHourlyChart ---

// --- Badge Management ---
function updateBadge() {
    if (!userSettings.showBadge || !weatherData?.currentConditions) {
        clearBadge();
        return;
    }

    const temp = Math.round(weatherData.currentConditions.temp);
    const unitSuffix = userSettings.units === 'metric' ? 'C' : 'F';
    const tempText = `${temp}°${unitSuffix}`;

    if (chrome.action) {
        chrome.action.setBadgeText({ text: tempText });
        chrome.action.setBadgeBackgroundColor({ color: '#36b6e5' }); 
    } else {
        console.warn("chrome.action API unavailable for setting badge text.");
    }
}

function clearBadge() {
    if (chrome.action) {
        chrome.action.setBadgeText({ text: '' }); 
    }
}

function getDayOfWeek(date) {
    if (!(date instanceof Date) || isNaN(date)) {
        return '---'; 
    }
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return days[date.getDay()];
}

function formatHour(hour) {
    const h = hour % 12 || 12; 
    const ampm = hour < 12 || hour === 24 ? 'am' : 'pm';
    if (hour === 24) return '12am'; 
    return `${h}${ampm}`;
}

function getWeatherIconUrl(icon) {
    const iconMap = {
        'clear-day': 'image/clear-day.png',
        'clear-night': 'image/clear-night.png',
        'partly-cloudy-day': 'image/partly-cloudy-day.png',
        'partly-cloudy-night': 'image/partly-cloudy-night.png',
        'cloudy': 'image/cloudy.png',
        'rain': 'image/rain.png',
        'snow': 'image/snow.png',
        'sleet': 'image/sleet.png', 
        'wind': 'image/wind.png',
        'fog': 'image/fog.png',
        'rain-snow': 'image/sleet.png',
        'rain-snow-showers-day': 'image/sleet.png',
        'rain-snow-showers-night': 'image/sleet.png',
        'showers-day': 'image/rain.png',
        'showers-night': 'image/rain.png',
        'snow-showers-day': 'image/snow.png',
        'snow-showers-night': 'image/snow.png',
        'thunder-rain': 'image/thunderstorm.png', 
        'thunder-showers-day': 'image/thunderstorm.png',
        'thunder-showers-night': 'image/thunderstorm.png',
        'thunder': 'image/thunderstorm.png'
    };
    return iconMap[icon] || 'image/loading.png';
}

