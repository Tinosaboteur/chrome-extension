// Global variables
let weatherData = null;
let airQualityData = null;
let userSettings = {
  apiKey: 'ELBNC7KRNHRYQ8KLL4N7E6H23', // Will prompt user to enter API key
  units: 'metric', // metric or us
  darkMode: false,
  showBadge: true,
  language: 'en',
  locationName: '' 
};
const defaultApiKey = ''; // Replace with a default API key if you have one

// DOM elements
const currentTempElement = document.getElementById('current-temp');
const weatherConditionElement = document.getElementById('weather-condition');
const celsiusUnitElement = document.getElementById('celsius-unit');
const fahrenheitUnitElement = document.getElementById('fahrenheit-unit');
const tempHighElement = document.getElementById('temp-high');
const tempLowElement = document.getElementById('temp-low');
const feelsLikeTempElement = document.getElementById('feels-like-temp');
const feelsLikeTempMinElement = document.getElementById('feels-like-temp-min');
const feelsLikeTempMaxElement = document.getElementById('feels-like-temp-max');
const weatherAlertElement = document.getElementById('weather-alert');
const locationTextElement = document.getElementById('location-text');
const refreshButtonElement = document.getElementById('refresh-button');
const humidityElement = document.getElementById('humidity');
const windSpeedElement = document.getElementById('wind-speed');
const windDirectionElement = document.getElementById('wind-direction');
const hourlyForecastElement = document.getElementById('hourly-forecast');
const sunriseTimeElement = document.getElementById('sunrise-time');
const sunsetTimeElement = document.getElementById('sunset-time');
const pm1Element = document.getElementById('pm1');
const pm2p5Element = document.getElementById('pm2p5');
const pm10Element = document.getElementById('pm10');
const so2Element = document.getElementById('so2');
const no2Element = document.getElementById('no2');
const o3Element = document.getElementById('o3');
const coElement = document.getElementById('co');
const aqiusElement = document.getElementById('aqius');
const aqieurElement = document.getElementById('aqieur');
const updateTimeElement = document.getElementById('update-time');
const unitsSelectorElement = document.getElementById('units-selector');
const settingsButtonElement = document.getElementById('settings-button');
const screenshotButtonElement = document.getElementById('screenshot-button');
const settingsModalElement = document.getElementById('settings-modal');
const closeModalElement = document.querySelector('.close-modal');
const darkModeToggleElement = document.getElementById('dark-mode-toggle');
const showBadgeToggleElement = document.getElementById('show-badge-toggle');
const languageSelectorElement = document.getElementById('language-selector');
const apiKeyInputElement = document.getElementById('api-key-input');
const saveSettingsButtonElement = document.getElementById('save-settings');
const locationInputElement = document.getElementById('location-input');
const uvindexElement = document.getElementById('uvindex');
const uvindexElementclass = document.getElementsByClassName('uvindex');

// Initialize the extension
document.addEventListener('DOMContentLoaded', () => {
  // Load settings from storage
  loadSettings();

  // Setup event listeners
  setupEventListeners();

  // Update UI with initial data
  updateUI();

  // Get weather data
  getWeatherData();
});

// Load user settings from Chrome storage
function loadSettings() {
  chrome.storage.sync.get(['userSettings'], (result) => {
    if (result.userSettings) {
      userSettings = result.userSettings;
      userSettings.apiKey = 'ELBNC7KRNHRYQ8KLL4N7E6H23';
      // Apply settings to UI
      darkModeToggleElement.checked = userSettings.darkMode;
      showBadgeToggleElement.checked = userSettings.showBadge;
      languageSelectorElement.value = userSettings.language;
      unitsSelectorElement.value = userSettings.units;
      apiKeyInputElement.value = userSettings.apiKey;
      locationInputElement.value = userSettings.locationName || '';
      celsiusUnitElement.classList.toggle('active', userSettings.units === 'metric');
      fahrenheitUnitElement.classList.toggle('active', userSettings.units === 'us');
      getWeatherData();
      // Apply dark mode if enabled
      if (userSettings.darkMode) {
        document.body.classList.add('dark-mode');
      }
    } else {
      // First time user, prompt for API key
      setTimeout(() => {
        settingsModalElement.classList.remove('hidden');
        apiKeyInputElement.focus();
      }, 500);
    }
  });
}

// Save user settings to Chrome storage
function saveSettings() {
  chrome.storage.sync.set({ userSettings }, () => {
    console.log('Settings saved');
  });

}

// Setup event listeners
function setupEventListeners() {
  // Temperature unit toggle
  celsiusUnitElement.addEventListener('click', () => {
    setTemperatureUnit('metric');
  });

  fahrenheitUnitElement.addEventListener('click', () => {
    setTemperatureUnit('us');
  });

  // Refresh button
  refreshButtonElement.addEventListener('click', () => {
    getWeatherData();
  });

  // Units selector
  unitsSelectorElement.addEventListener('change', (e) => {
    userSettings.units = e.target.value;
    saveSettings();
    getWeatherData();
    updateTemperatureDisplay();
    celsiusUnitElement.classList.toggle('active', userSettings.units === 'metric');
    fahrenheitUnitElement.classList.toggle('active', userSettings.units === 'us');
  });

  // Settings button
  settingsButtonElement.addEventListener('click', () => {
    settingsModalElement.classList.remove('hidden');
  });

  // Close modal
  closeModalElement.addEventListener('click', () => {
    settingsModalElement.classList.add('hidden');
  });

  // Save settings
  saveSettingsButtonElement.addEventListener('click', () => {
    userSettings.darkMode = darkModeToggleElement.checked;
    userSettings.showBadge = showBadgeToggleElement.checked;
    userSettings.language = languageSelectorElement.value;
    userSettings.apiKey = apiKeyInputElement.value;
    userSettings.locationName = locationInputElement.value.trim();
    // Apply dark mode if enabled
    if (userSettings.darkMode) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }

    saveSettings();
    settingsModalElement.classList.add('hidden');

    // Refresh weather data with new settings
    getWeatherData();

    // Update badge if enabled
    if (userSettings.showBadge) {
      updateBadge();
    } else {
      clearBadge();
    }
  });

  // Setup accordion toggles
  document.querySelectorAll('.accordion-header').forEach(header => {
    header.addEventListener('click', () => {
      const content = header.nextElementSibling;
      content.classList.toggle('active');

      // Update arrow icon
      const icon = header.querySelector('.accordion-icon');
      if (content.classList.contains('active')) {
        icon.textContent = '▲';
      } else {
        icon.textContent = '▼';
      }
    });
  });

  // Screenshot button
  screenshotButtonElement.addEventListener('click', () => {
    // This would normally capture the current view and download as an image
    // For Chrome extensions, this would require additional permissions and chrome.tabs API
    alert('Screenshot functionality would be implemented here');
  });
}

// Set temperature unit (metric or us)
function setTemperatureUnit(unit) {
  userSettings.units = unit;
  
  celsiusUnitElement.classList.toggle('active', unit === 'metric');
  fahrenheitUnitElement.classList.toggle('active', unit === 'us');
  getWeatherData();
  saveSettings();
  
  // Update UI
  // Update temperature display
  updateTemperatureDisplay();
}

// Update temperature display based on selected unit
function updateTemperatureDisplay() {
  if (!weatherData) return;

  const currentTemp = weatherData.currentConditions.temp;

  const feelsLike = weatherData.currentConditions.feelslike

  const feelsLikeMax = weatherData.days[0].feelslikemax

  const feelsLikeMin = weatherData.days[0].feelslikemin

  const tempHigh = weatherData.days[0].tempmax

  const tempLow = weatherData.days[0].tempmin

  const unit = userSettings.units === 'metric' ? '°C' : '°F';

  currentTempElement.textContent = currentTemp;
  feelsLikeTempElement.textContent = `${feelsLike.toFixed(1)}${unit}`;
  feelsLikeTempMinElement.textContent = `↓ ${feelsLikeMin.toFixed(1)}${unit}`;
  feelsLikeTempMaxElement.textContent = `↑ ${feelsLikeMax.toFixed(1)}${unit}`;
  tempHighElement.textContent = `↑ ${tempHigh.toFixed(1)}${unit}`;
  tempLowElement.textContent = `↓ ${tempLow.toFixed(1)}${unit}`;

  const uvindexValue = weatherData.currentConditions.uvindex;
uvindexElement.textContent = uvindexValue;

// Thay đổi màu sắc và kiểu dáng dựa trên mức độ UV Index
if (uvindexValue <= 2) {
  uvindexElement.parentElement.className = 'uvindex-highlight-low'; 
} else if (uvindexValue <= 5) {
  uvindexElement.parentElement.className = 'uvindex-highlight-moderate'; 
} else if (uvindexValue <= 7) {
  uvindexElement.parentElement.className = 'uvindex-highlight-high'; 
} else if (uvindexValue <= 10) {
  uvindexElement.parentElement.className = 'uvindex-highlight-very-high'; 

  // Thêm ảnh cảnh báo khi UV Index trên 7
  const alertImage = document.getElementById('alert-none');
  alertImage.src = 'image/alert.png';
  alertImage.alt = 'UV Alert';
  alertImage.style.width = '30px'; 
  alertImage.style.marginLeft = '10px';
} else {
  uvindexElement.parentElement.className = 'uvindex highlight extreme'; 

  const alertImage = document.getElementById('alert-none');
  alertImage.src = 'image/alert.png'; 
  alertImage.alt = 'UV Alert';
  alertImage.style.width = '30px'; 
  alertImage.style.marginLeft = '10px'; 
}
  // Update 7-day forecast
  updateForecastDisplay();
}

// Update the 7-day forecast display
function updateForecastDisplay() {
  if (!weatherData || !weatherData.days) return;

  // Find min and max temps for the 7-day period to scale the bars
  let minTemp = Infinity;
  let maxTemp = -Infinity;

  weatherData.days.slice(0, 7).forEach(day => {
    const min =  day.tempmin;
    const max =  day.tempmax;

    if (min < minTemp) minTemp = min;
    if (max > maxTemp) maxTemp = max;
  });

  const tempRange = maxTemp - minTemp;

  // Update each day
  weatherData.days.slice(0, 7).forEach((day, index) => {
    const date = new Date(day.datetime);
    const dayOfWeek = index === 0 ? 'Today' : getDayOfWeek(date);

    const minTemp = day.tempmin;
    const maxTemp = day.tempmax;

    document.getElementById(`day-${index}`).textContent = dayOfWeek;
    document.getElementById(`icon-${index}`).innerHTML = `<img src="${getWeatherIconUrl(day.icon)}" alt="${day.conditions}">`;
    document.getElementById(`high-${index}`).textContent = `${Math.round(maxTemp)}°`;
    document.getElementById(`low-${index}`).textContent = `${Math.round(minTemp)}°`;

    // Calculate bar height as percentage of temperature range
    const barHeight = ((maxTemp - minTemp) / tempRange) * 100;
    const barOffset = ((minTemp - minTemp) / tempRange) * 100;

    const barElement = document.getElementById(`bar-${index}`).querySelector('.bar-fill');
    barElement.style.height = `${barHeight}%`;
  });
}

// Fetch weather data from Visual Crossing API
function getWeatherData() {
  if (!userSettings.apiKey && !defaultApiKey) {
    settingsModalElement.classList.remove('hidden');
    apiKeyInputElement.focus();
    return;
  }

  weatherConditionElement.textContent = 'Loading...';
  const apiKey = userSettings.apiKey || defaultApiKey;
  const locationQuery = locationInputElement.value.trim();

  if (locationQuery) {
    // Nếu người dùng nhập tên địa điểm
    Promise.all([
      getAirQualityData(locationQuery),
      fetchWeatherByLocation(locationQuery, apiKey)
    ]).then(() => {
      updateUI(); // Chỉ gọi updateUI sau khi cả hai hàm hoàn thành
    }).catch(error => {
      console.error('Error fetching weather or air quality data:', error);
    });

  } else {
    // Nếu không có, dùng geolocation
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;
        const coords = `${lat},${lon}`;
        Promise.all([
          getAirQualityData(coords),
          fetchWeatherByLocation(coords, apiKey)
        ]).then(() => {
          updateUI(); // Chỉ gọi updateUI sau khi cả hai hàm hoàn thành
        }).catch(error => {
          console.error('Error fetching weather or air quality data:', error);
        });
      },
      (error) => {
        console.error('Geolocation error:', error);
        weatherConditionElement.textContent = 'Location access denied';
      }
    );
  }
}
document.addEventListener('DOMContentLoaded', () => {
  const locationInputElement = document.getElementById('location-input');

  // Đặt giá trị mặc định là "Hồ Chí Minh"
  if (!locationInputElement.value) {
    locationInputElement.value = "Hồ Chí Minh";
  }

  // Lấy dữ liệu thời tiết ban đầu
  getWeatherData();
});

function getAirQualityData(locationString) {
  const urlairquality = `https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${encodeURIComponent(locationString)}?unitGroup=us&include=days,hours,current,alerts,airQuality&key=ELBNC7KRNHRYQ8KLL4N7E6H23&contentType=json&elements=datetime,pm1,pm2p5,pm10,o3,no2,so2,co,aqius,aqieur`;

  return fetch(urlairquality)
    .then(response => {
      if (!response.ok) throw new Error(`Weather API error: ${response.status}`);
      return response.json();
    })
    .then(data => {
      airQualityData = data; 
    })

}


function fetchWeatherByLocation(locationString, apiKey) {
  const unitGroup = userSettings.units;
  const url = `https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${encodeURIComponent(locationString)}?unitGroup=${unitGroup}&include=current,days,hours,alerts&key=${apiKey}&contentType=json`;

  fetch(url)
    .then(response => {
      if (!response.ok) throw new Error(`Weather API error: ${response.status}`);
      return response.json();
    })
    .then(data => {
      weatherData = data;
      updateTimeElement.textContent = new Date().toLocaleTimeString();

      // Chỉ cập nhật giá trị được chọn, không ghi đè nội dung <select>
      if (locationInputElement.value !== data.resolvedAddress) {
        locationInputElement.value = "Hồ Chí Minh"; // Giữ giá trị mặc định nếu không khớp
      }

      updateUI();
      if (userSettings.showBadge) {
        updateBadge();
      }
    })
    .catch(error => {
      console.error('Error fetching weather data:', error);
    });
}

// Update the UI with weather data
function updateUI() {
  if (!weatherData) return;

  // Update current conditions
  weatherConditionElement.textContent = weatherData.currentConditions.conditions;

  // Update temperature display
  updateTemperatureDisplay();

  // Weather details
  humidityElement.textContent = `${weatherData.currentConditions.humidity}%`;

  const windSpeed = userSettings.units === 'metric'
    ? `${weatherData.currentConditions.windspeed} km/h`
    : `${Math.round(weatherData.currentConditions.windspeed * 0.621371)} mph`;

  windSpeedElement.textContent = windSpeed;
  windDirectionElement.textContent = `${weatherData.currentConditions.winddir}°`;

  // Sunrise and sunset
 
  sunriseTimeElement.textContent = weatherData.days[0].sunrise;
  sunsetTimeElement.textContent = weatherData.days[0].sunset;

  // Hourly forecast
  updateHourlyForecast();

  // Air quality (Note: Visual Crossing might not provide this data, so we'll use placeholder values)
  // In a real implementation, you might need to use another API for air quality data 
  function updateAirQualityDisplay() {
    const setAirQualityColor = (element, value, thresholds) => {
      if (value === '--') {
        element.style.color = 'gray'; // Màu mặc định khi không có dữ liệu
      } else if (value <= thresholds.low) {
        element.style.color = 'green'; // Mức thấp
      } else if (value <= thresholds.medium) {
        element.style.color = 'orange'; // Mức trung bình
      } else {
        element.style.color = 'red'; // Mức cao
      }
    };
  
    const pm2p5Value = airQualityData.currentConditions.pm2p5 || '--';
    pm2p5Element.textContent = pm2p5Value !== '--' ? `${pm2p5Value} μg/m³` : '-- μg/m³';
    setAirQualityColor(pm2p5Element, pm2p5Value, { low: 12, medium: 35 });
  
    const pm10Value = airQualityData.currentConditions.pm10 || '--';
    pm10Element.textContent = pm10Value !== '--' ? `${pm10Value} μg/m³` : '-- μg/m³';
    setAirQualityColor(pm10Element, pm10Value, { low: 20, medium: 50 });
  
    const pm1Value = airQualityData.currentConditions.pm1 || '--';
    pm1Element.textContent = pm1Value !== '--' ? `${pm1Value} μg/m³` : '-- μg/m³';
    setAirQualityColor(pm1Element, pm1Value, { low: 10, medium: 25 });
  
    const so2Value = airQualityData.currentConditions.so2 || '--';
    so2Element.textContent = so2Value !== '--' ? `${so2Value} μg/m³` : '-- μg/m³';
    setAirQualityColor(so2Element, so2Value, { low: 20, medium: 75 });
  
    const no2Value = airQualityData.currentConditions.no2 || '--';
    no2Element.textContent = no2Value !== '--' ? `${no2Value} μg/m³` : '-- μg/m³';
    setAirQualityColor(no2Element, no2Value, { low: 40, medium: 100 });
  
    const o3Value = airQualityData.currentConditions.o3 || '--';
    o3Element.textContent = o3Value !== '--' ? `${o3Value} μg/m³` : '-- μg/m³';
    setAirQualityColor(o3Element, o3Value, { low: 50, medium: 120 });
  
    const coValue = airQualityData.currentConditions.co || '--';
    coElement.textContent = coValue !== '--' ? `${coValue} μg/m³` : '-- μg/m³';
    setAirQualityColor(coElement, coValue, { low: 4, medium: 10 });
  
    const aqiusValue = airQualityData.currentConditions.aqius || '--';
    aqiusElement.textContent = aqiusValue !== '--' ? `${aqiusValue}` : '--';
    setAirQualityColor(aqiusElement, aqiusValue, { low: 50, medium: 100 });
  
    const aqieurValue = airQualityData.currentConditions.aqieur || '--';
    aqieurElement.textContent = aqieurValue !== '--' ? `${aqieurValue}` : '--';
    setAirQualityColor(aqieurElement, aqieurValue, { low: 50, medium: 100 });
  }
  updateAirQualityDisplay();

  

  // Check for weather alerts
  if (weatherData.alerts && weatherData.alerts.length > 0) {
    weatherAlertElement.classList.remove('hidden');
    weatherAlertElement.title = weatherData.alerts[0].title;
  } else {
    weatherAlertElement.classList.add('hidden');
  }
}

// Update hourly forecast
function updateHourlyForecast() {
  if (!weatherData || !weatherData.hours) return;

  console.log('Updating hourly forecast...');
  // Clear existing content
  hourlyForecastElement.innerHTML = '';

  // Get current hour to start from
  const currentHour = new Date().getHours();

  // Display next 12 hours
  for (let i = 0; i < 12; i++) {
    const hourIndex = currentHour + i;
    if (hourIndex >= 24) break;

    const hourData = weatherData.days[0].hours[hourIndex];
    if (!hourData) continue;

    const temp = hourData.temp;

    const hourItem = document.createElement('div');
    hourItem.classList.add('hour-item');

    const time = formatHour(hourIndex);

    hourItem.innerHTML = `
      <div>${time}</div>
      <img src="${getWeatherIconUrl(hourData.icon)}" alt="${hourData.conditions}">
      <div>${Math.round(temp)}°</div>
    `;

    hourlyForecastElement.appendChild(hourItem);
  }
}

// Update the extension badge with current temperature
function updateBadge() {
  if (!weatherData) return;

  const temp = weatherData.currentConditions.temp;

  const tempText = `${temp}°`;

  // Use chrome.action API to update badge
  if (chrome.action) {
    chrome.action.setBadgeText({ text: tempText });
    chrome.action.setBadgeBackgroundColor({ color: '#36b6e5' });
  }
}

// Clear the extension badge
function clearBadge() {
  if (chrome.action) {
    chrome.action.setBadgeText({ text: '' });
  }
}

// Helper function to get day of week from date
function getDayOfWeek(date) {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  return days[date.getDay()];
}

// Helper function to format time (HH:MM)
function formatTime(date) {
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

// Helper function to format hour (HH:MM)
function formatHour(hour) {
  return `${hour % 12 || 12}${hour < 12 ? 'am' : 'pm'}`;
}

// Helper function to get weather icon URL based on condition code
function getWeatherIconUrl(icon) {
  // Using a mapping of Visual Crossing icon codes to our own icon files
  // This would need to be customized based on your actual icon files
  const iconMap = {
    'clear-day': 'image/clear-day.png',
    'clear-night': 'image/clear-night.png',
    'partly-cloudy-day': 'image/partly-cloudy-day.png',
    'partly-cloudy-night': 'image/partly-cloudy-night.png',
    'cloudy': 'image/cloudy.png',
    'rain': 'image/rain.png',
    'snow': 'image/snow.png',
    'sleet': 'image/sleet.png',
    'wind': 'image/wind.png',
    'fog': 'image/fog.png'
  };

  // Return the icon URL or a default icon if not found
  return iconMap[icon] || 'image/logo.png';
}



