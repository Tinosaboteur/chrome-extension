let weatherData = null;
let airQualityData = null;
let hourlyChart = null;
let selectedDayIndex = 0; // Index of the day selected in the 7-day forecast
let userSettings = {
    apiKey: 'ELBNC7KRNHRYQ8KLL4N7E6H23', // Default API Key
    units: 'metric', // 'metric' or 'us'
    darkMode: false,
    showBadge: true,
    language: 'vi-VN',
    locationName: 'Hồ Chí Minh', // Default location
    reminderTime: '07:00' // Default reminder time (HH:MM format)
};
const defaultApiKey = 'ELBNC7KRNHRYQ8KLL4N7E6H23';

// Cache DOM Elements
const currentTempElement = document.getElementById('current-temp');
const weatherConditionElement = document.getElementById('weather-condition');
const celsiusUnitElement = document.getElementById('celsius-unit');
const fahrenheitUnitElement = document.getElementById('fahrenheit-unit');
const tempHighElement = document.getElementById('temp-high');
const tempLowElement = document.getElementById('temp-low');
const feelsLikeTempElement = document.getElementById('feels-like-temp');
const feelsLikeTempMinElement = document.getElementById('feels-like-temp-min');
const feelsLikeTempMaxElement = document.getElementById('feels-like-temp-max');
const weatherAlertElement = document.getElementById('weather-alert');
const refreshButtonElement = document.getElementById('refresh-button');
const humidityElement = document.getElementById('humidity');
const windSpeedElement = document.getElementById('wind-speed');
const windDirectionElement = document.getElementById('wind-direction');
const pressureElement = document.getElementById('pressure');
const visibilityElement = document.getElementById('visibility');
const cloudcoverElement = document.getElementById('cloud-cover');
const solarenergyElement = document.getElementById('solar-energy');
const sunriseTimeElement = document.getElementById('sunrise-time');
const sunsetTimeElement = document.getElementById('sunset-time');
const pm1Element = document.getElementById('pm1');
const pm2p5Element = document.getElementById('pm2p5');
const pm10Element = document.getElementById('pm10');
const so2Element = document.getElementById('so2');
const no2Element = document.getElementById('no2');
const o3Element = document.getElementById('o3');
const coElement = document.getElementById('co');
const aqiusElement = document.getElementById('aqius');
const aqieurElement = document.getElementById('aqieur');
const updateTimeElement = document.getElementById('update-time');
const unitsSelectorElement = document.getElementById('units-selector');
const settingsButtonElement = document.getElementById('settings-button');
const screenshotButtonElement = document.getElementById('screenshot-button');
const settingsModalElement = document.getElementById('settings-modal');
const closeModalElement = document.querySelector('.close-modal');
const darkModeToggleElement = document.getElementById('dark-mode-toggle');
const showBadgeToggleElement = document.getElementById('show-badge-toggle');
const languageSelectorElement = document.getElementById('language-selector');
const apiKeyInputElement = document.getElementById('api-key-input');
const reminderTimeInputElement = document.getElementById('reminder-time-input'); // Added
const saveSettingsButtonElement = document.getElementById('save-settings');
const locationInputElement = document.getElementById('location-input');
const uvindexElement = document.getElementById('uvindex');
const uvindexContainerElement = document.querySelector('.uvindex');
const alertNoneImage = document.getElementById('alert-none');
const hourlyChartCanvas = document.getElementById('hourly-chart');
const headerDayNameElement = document.getElementById('header-day-name');
const forecastDaysContainer = document.querySelector('.forecast-days');
const reminderMessageContainer = document.getElementById('reminder-message-container'); // Added
const reminderMessageElement = document.getElementById('reminder-message'); // Added


// Plugin cho Chart.js để hiển thị icon và nhiệt độ trên biểu đồ hàng giờ
const hourlyIconsPlugin = {
    id: 'hourlyIcons',
    afterDatasetsDraw(chart, args, options) {
        const { ctx } = chart;
        const meta = chart.getDatasetMeta(0);
        const elements = meta.data || [];
        const icons = chart.config.data.datasets[0].icons || [];
        const temps = chart.config.data.datasets[0].data || [];
        const unitSuffix = chart.config.data.datasets[0].unitSuffix || '';

        const iconSize = options.iconSize || 20;
        const iconTopMargin = options.iconTopMargin || 5;
        const textYOffset = options.textYOffset || 8;
        const textColor = options.textColor || '#000';
        const textFont = options.textFont || '10px Roboto';

        ctx.save();
        ctx.font = textFont;
        ctx.fillStyle = textColor;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';

        elements.forEach((element, index) => {
            if (!element.skip && temps[index] != null) { // Check if temp is not null
                const vm = element.getProps(['x', 'y']);
                const tempValue = temps[index];

                // Vẽ icon thời tiết
                if (icons[index] && icons[index].complete && icons[index].naturalHeight !== 0) {
                    const icon = icons[index];
                    const iconX = vm.x - (iconSize / 2);
                    const iconY = iconTopMargin;
                    ctx.drawImage(icon, iconX, iconY, iconSize, iconSize);
                }

                // Vẽ giá trị nhiệt độ
                 const tempText = `${Math.round(tempValue)}${unitSuffix}`;
                 const textX = vm.x;
                 // Adjust text Y position to be *below* the point, closer to the icon
                 const textY = vm.y + iconSize + textYOffset - 5; // Adjusted Y
                 ctx.fillText(tempText, textX, textY);

            }
        });
        ctx.restore();
    }
};

// Đăng ký plugin với Chart.js nếu chưa đăng ký
if (typeof Chart !== 'undefined' && !Chart.registry.plugins.get(hourlyIconsPlugin.id)) {
    Chart.register(hourlyIconsPlugin);
}

// Chạy khi nội dung DOM đã tải xong
document.addEventListener('DOMContentLoaded', () => {
    loadSettings();
    setupEventListeners();
});

/**
 * Tải cài đặt người dùng từ bộ nhớ đồng bộ của Chrome.
 * Nếu không có cài đặt, lưu cài đặt mặc định.
 */
function loadSettings() {
    chrome.storage.sync.get(['userSettings'], (result) => {
        if (result.userSettings) {
            userSettings = { ...userSettings, ...result.userSettings };
            // Đảm bảo API key không bị rỗng sau khi load
            userSettings.apiKey = userSettings.apiKey || defaultApiKey;
        } else {
            // Nếu không có cài đặt, lưu cài đặt mặc định
            saveSettings();
            // Nếu API key mặc định cũng rỗng (trường hợp hiếm), hiển thị modal
            if (!userSettings.apiKey) {
                showSettingsModal();
            }
        }
        // Áp dụng cài đặt lên UI và lấy dữ liệu thời tiết
        applySettingsToUI();
        getWeatherData();
    });
}

/**
 * Áp dụng các cài đặt đã tải lên các thành phần giao diện người dùng.
 */
function applySettingsToUI() {
    darkModeToggleElement.checked = userSettings.darkMode;
    showBadgeToggleElement.checked = userSettings.showBadge;
    languageSelectorElement.value = userSettings.language;
    unitsSelectorElement.value = userSettings.units;
    apiKeyInputElement.value = userSettings.apiKey;
    locationInputElement.value = userSettings.locationName;
    reminderTimeInputElement.value = userSettings.reminderTime || '07:00'; // Set default if null

    celsiusUnitElement.classList.toggle('active', userSettings.units === 'metric');
    fahrenheitUnitElement.classList.toggle('active', userSettings.units === 'us');

    document.body.classList.toggle('dark-mode', userSettings.darkMode);
}

/**
 * Hiển thị modal cài đặt và điền các giá trị hiện tại.
 */
function showSettingsModal() {
    darkModeToggleElement.checked = userSettings.darkMode;
    showBadgeToggleElement.checked = userSettings.showBadge;
    languageSelectorElement.value = userSettings.language;
    apiKeyInputElement.value = userSettings.apiKey;
    reminderTimeInputElement.value = userSettings.reminderTime || '07:00'; // Show current or default

    settingsModalElement.classList.remove('hidden');
    // Tự động focus vào ô API key nếu nó trống
    if (!apiKeyInputElement.value) {
        apiKeyInputElement.focus();
    }
}

/**
 * Lưu cài đặt hiện tại của người dùng vào bộ nhớ đồng bộ Chrome.
 */
function saveSettings() {
    chrome.storage.sync.set({ userSettings }, () => {
        console.log('Cài đặt đã lưu:', userSettings);
    });
}

/**
 * Thiết lập các trình lắng nghe sự kiện cho các tương tác của người dùng.
 */
function setupEventListeners() {
    // Chuyển đổi đơn vị nhiệt độ
    celsiusUnitElement.addEventListener('click', () => setTemperatureUnit('metric'));
    fahrenheitUnitElement.addEventListener('click', () => setTemperatureUnit('us'));

    // Thay đổi vị trí
    locationInputElement.addEventListener('change', (e) => {
        userSettings.locationName = e.target.value;
        saveSettings();
        getWeatherData(); // Lấy lại dữ liệu cho vị trí mới
    });

    // Nút làm mới
    refreshButtonElement.addEventListener('click', getWeatherData);

    // Chọn đơn vị từ dropdown (footer)
    unitsSelectorElement.addEventListener('change', (e) => {
        userSettings.units = e.target.value;
        celsiusUnitElement.classList.toggle('active', userSettings.units === 'metric');
        fahrenheitUnitElement.classList.toggle('active', userSettings.units === 'us');
        saveSettings();
        getWeatherData(); // Lấy lại dữ liệu với đơn vị mới
    });

    // Mở modal cài đặt
    settingsButtonElement.addEventListener('click', showSettingsModal);

    // Đóng modal cài đặt
    closeModalElement.addEventListener('click', () => {
        settingsModalElement.classList.add('hidden');
    });
    settingsModalElement.addEventListener('click', (event) => {
        if (event.target === settingsModalElement) { // Chỉ đóng nếu click vào nền modal
            settingsModalElement.classList.add('hidden');
        }
    });

    // Lưu cài đặt từ modal
    saveSettingsButtonElement.addEventListener('click', () => {
        const oldDarkMode = userSettings.darkMode;

        // Cập nhật userSettings từ các input trong modal
        userSettings.darkMode = darkModeToggleElement.checked;
        userSettings.showBadge = showBadgeToggleElement.checked;
        userSettings.language = languageSelectorElement.value;
        userSettings.apiKey = apiKeyInputElement.value.trim() || defaultApiKey; // Use default if empty
        userSettings.locationName = locationInputElement.value.trim(); // Location saved from main UI, but sync here too
        userSettings.reminderTime = reminderTimeInputElement.value || '07:00'; // Save reminder time

        // Áp dụng dark mode nếu thay đổi
        if (userSettings.darkMode !== oldDarkMode) {
            document.body.classList.toggle('dark-mode', userSettings.darkMode);
            // Vẽ lại biểu đồ nếu đang mở để cập nhật màu sắc
            const hourlyContent = document.getElementById('hourly-forecast-content');
            if (hourlyContent?.classList.contains('active')) {
                renderHourlyChart(); // Re-render with potentially new colors
            }
        }

        saveSettings(); // Lưu vào storage
        settingsModalElement.classList.add('hidden'); // Đóng modal
        getWeatherData(); // Tải lại dữ liệu với cài đặt mới

        // Xóa badge nếu người dùng tắt
        if (!userSettings.showBadge) {
            clearBadge();
        }
    });

    // Xử lý accordion
    document.querySelectorAll('.accordion-header').forEach(header => {
        header.addEventListener('click', () => {
            const content = header.nextElementSibling;
            const icon = header.querySelector('.accordion-icon');
            const isActive = content.classList.toggle('active'); // Toggle và lấy trạng thái mới
            icon.textContent = isActive ? '▲' : '▼'; // Cập nhật icon

            // Đặc biệt xử lý cho biểu đồ hàng giờ
            if (header.id === 'hourly-forecast-header') {
                if (isActive) {
                    renderHourlyChart(); // Vẽ biểu đồ khi mở accordion
                } else if (hourlyChart) {
                    hourlyChart.destroy(); // Hủy biểu đồ khi đóng
                    hourlyChart = null;
                }
            }
        });
    });

    // Xử lý click chọn ngày trong dự báo 7 ngày
    forecastDaysContainer.addEventListener('click', (event) => {
        const dayLabel = event.target.closest('.day-label');
        if (dayLabel && dayLabel.dataset.index !== undefined) {
            const newIndex = parseInt(dayLabel.dataset.index, 10);
            // Chỉ cập nhật nếu index hợp lệ và khác index hiện tại
            if (!isNaN(newIndex) && newIndex !== selectedDayIndex) {
                selectedDayIndex = newIndex;
                updateUI(); // Cập nhật toàn bộ UI cho ngày mới được chọn
                // Lưu ý: Biểu đồ hàng giờ không cần vẽ lại ở đây vì nó hiển thị 24h tới
            }
        }
    });

    // Nút chụp ảnh màn hình
    screenshotButtonElement.addEventListener('click', () => {
        if (typeof chrome !== 'undefined' && chrome.tabs?.captureVisibleTab) {
            chrome.tabs.captureVisibleTab(null, {}, (image) => {
                // Kiểm tra lỗi runtime
                if (chrome.runtime.lastError) {
                    console.error("Lỗi chụp ảnh màn hình:", chrome.runtime.lastError.message);
                    alert("Không thể chụp ảnh màn hình. Lỗi: " + chrome.runtime.lastError.message);
                    return;
                }
                // Tạo link tải ảnh
                const link = document.createElement('a');
                link.download = 'thinkweather_screenshot.png';
                link.href = image;
                link.click(); // Tự động click để tải
            });
        } else {
            alert('Tính năng chụp ảnh màn hình không khả dụng trong môi trường này.');
            console.warn('API chrome.tabs.captureVisibleTab không khả dụng.');
        }
    });
}

/**
 * Đặt đơn vị nhiệt độ (metric hoặc us) và tải lại dữ liệu.
 * @param {string} unit - Đơn vị mới ('metric' hoặc 'us').
 */
function setTemperatureUnit(unit) {
    if (userSettings.units === unit) return; // Không làm gì nếu đơn vị đã đúng

    userSettings.units = unit;
    celsiusUnitElement.classList.toggle('active', unit === 'metric');
    fahrenheitUnitElement.classList.toggle('active', unit === 'us');
    unitsSelectorElement.value = unit; // Đồng bộ dropdown ở footer
    saveSettings();
    getWeatherData(); // Lấy lại dữ liệu với đơn vị mới
}

/**
 * Lấy dữ liệu thời tiết và chất lượng không khí từ API Visual Crossing.
 * Sử dụng vị trí đã lưu hoặc vị trí hiện tại nếu không có.
 */
function getWeatherData() {
    // Kiểm tra API key
    if (!userSettings.apiKey) {
        console.error("Thiếu API Key.");
        weatherConditionElement.textContent = 'Cần API Key';
        showSettingsModal(); // Mở modal để người dùng nhập key
        return;
    }

    weatherConditionElement.textContent = 'Đang tải...'; // Thông báo đang tải
    const apiKey = userSettings.apiKey;
    const locationQuery = userSettings.locationName.trim(); // Lấy vị trí từ cài đặt

    // Hàm để thực hiện fetch dữ liệu cho một vị trí cụ thể
    const fetchDataForLocation = (loc) => {
        const encodedLoc = encodeURIComponent(loc); // Mã hóa vị trí cho URL
        const weatherUrl = `https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${encodedLoc}`
                         + `?unitGroup=${userSettings.units}` // Đơn vị metric/us
                         + `&include=days,hours,current,alerts` // Dữ liệu cần lấy
                         + `&key=${apiKey}&contentType=json`;

        const airQualityUrl = `https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${encodedLoc}`
                            + `?unitGroup=${userSettings.units}`
                            + `&include=current,airQuality` // Chỉ cần AQ hiện tại
                            + `&key=${apiKey}&contentType=json`
                            + `&elements=datetime,pm1,pm2p5,pm10,o3,no2,so2,co,aqius,aqieur`; // Các chỉ số AQ cụ thể

        // Reset dữ liệu cũ
        weatherData = null;
        airQualityData = null;
        selectedDayIndex = 0; // Luôn reset về ngày hôm nay khi tải lại

        // Gọi cả hai API cùng lúc
        Promise.all([
            fetch(weatherUrl).then(handleApiResponse),
            fetch(airQualityUrl).then(handleApiResponse)
        ])
        .then(([weatherResult, airQualityResult]) => {
            console.log("Dữ liệu thời tiết thô:", weatherResult);
            console.log("Dữ liệu AQ thô:", airQualityResult);

            // Xử lý dữ liệu thời tiết
            if (weatherResult?.days?.length > 0 && weatherResult.days[0]?.hours) {
                weatherData = weatherResult;
                updateTimeElement.textContent = new Date().toLocaleTimeString('vi-VN', {
                    hour: '2-digit', minute: '2-digit'
                }); // Cập nhật thời gian update
                if (userSettings.showBadge) {
                    updateBadge(); // Cập nhật badge nếu được bật
                }
            } else {
                console.error("Dữ liệu thời tiết không hợp lệ:", weatherResult);
                weatherData = null;
            }

            // Xử lý dữ liệu chất lượng không khí
            if (airQualityResult?.currentConditions) {
                airQualityData = airQualityResult;
            } else {
                console.warn("Dữ liệu chất lượng không khí không hợp lệ hoặc không có:", airQualityResult);
                airQualityData = null;
            }

            updateUI(); // Cập nhật giao diện với dữ liệu mới
            checkAndDisplayReminder(); // Kiểm tra và hiển thị nhắc nhở

            // Nếu không có dữ liệu thời tiết, hiển thị lỗi
            if (!weatherData) {
                weatherConditionElement.textContent = 'Tải thất bại';
            }
        })
        .catch(error => {
            console.error('Lỗi fetch dữ liệu:', error);
            weatherConditionElement.textContent = 'Lỗi tải dữ liệu';
            weatherData = null;
            airQualityData = null;
            updateUI(); // Cập nhật UI để hiển thị trạng thái lỗi
            checkAndDisplayReminder(); // Xóa nhắc nhở cũ
        });
    };

    // Xác định vị trí để fetch dữ liệu
    if (locationQuery) { // Nếu có vị trí trong cài đặt
        fetchDataForLocation(locationQuery);
    } else { // Nếu không, thử lấy vị trí hiện tại
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => { // Lấy vị trí thành công
                    fetchDataForLocation(`${position.coords.latitude},${position.coords.longitude}`);
                },
                (error) => { // Lỗi lấy vị trí
                    console.error('Lỗi Geolocation:', error);
                    weatherConditionElement.textContent = 'Vị trí không khả dụng';
                    userSettings.locationName = 'Hồ Chí Minh'; // Đặt vị trí mặc định
                    locationInputElement.value = userSettings.locationName;
                    saveSettings();
                    fetchDataForLocation(userSettings.locationName); // Fetch theo vị trí mặc định
                },
                { timeout: 10000 } // Timeout 10 giây
            );
        } else { // Trình duyệt không hỗ trợ geolocation
            console.warn("Geolocation không được hỗ trợ.");
            weatherConditionElement.textContent = 'Cần vị trí';
            userSettings.locationName = 'Hồ Chí Minh'; // Đặt vị trí mặc định
            locationInputElement.value = userSettings.locationName;
            saveSettings();
            fetchDataForLocation(userSettings.locationName); // Fetch theo vị trí mặc định
        }
    }
}

/**
 * Xử lý phản hồi từ API (kiểm tra lỗi và phân tích JSON).
 * @param {Response} response - Đối tượng Response từ fetch.
 * @returns {Promise<object|null>} - Promise chứa dữ liệu JSON hoặc null.
 */
function handleApiResponse(response) {
    if (!response.ok) { // Nếu status không phải 2xx
        return response.text().then(text => { // Đọc text lỗi từ body
            throw new Error(`Lỗi API ${response.status}: ${text || response.statusText}`);
        });
    }
    return response.text().then(text => {
        try {
            // Phân tích JSON, trả về null nếu text rỗng
            return text ? JSON.parse(text) : null;
        } catch (e) {
            console.error("Lỗi phân tích JSON:", e, "Response Text:", text);
            throw new Error("Không thể phân tích phản hồi API.");
        }
    });
}

/**
 * Cập nhật giao diện người dùng để làm nổi bật ngày được chọn trong dự báo 7 ngày.
 */
function updateDaySelectionUI() {
    // Bỏ chọn tất cả các ngày trước
    forecastDaysContainer.querySelectorAll('.day-label').forEach(label => {
        label.classList.remove('selected');
    });
    // Chọn ngày hiện tại
    const selectedLabel = forecastDaysContainer.querySelector(`.day-label[data-index="${selectedDayIndex}"]`);
    if (selectedLabel) {
        selectedLabel.classList.add('selected');
    }
    // Không cần render lại hourly chart ở đây nữa vì nó cố định 24h tới
}

/**
 * Dịch các điều kiện thời tiết sang tiếng Việt.
 * @param {string} condition - Điều kiện thời tiết tiếng Anh.
 * @returns {string} - Điều kiện thời tiết tiếng Việt.
 */
function translateWeatherCondition(condition) {
    const translations = {
        "Clear": "Trời quang",
        "Partially cloudy": "Ít mây",
        "Mostly cloudy": "Nhiều mây", // Added
        "Cloudy": "Nhiều mây", // Added alias
        "Overcast": "Âm u",
        "Rain, Partially cloudy": "Mưa, Ít mây", // Combined
        "Rain, Overcast": "Mưa, Âm u", // Combined
        "Rain": "Có mưa",
        "Snow": "Có tuyết",
        "Fog": "Sương mù",
        "Thunderstorm": "Giông bão",
        "Haze": "Mờ sương",
        "Drizzle": "Mưa phùn",
        "Sleet": "Mưa tuyết",
        "Freezing Rain": "Mưa đông lạnh",
        "Windy": "Gió mạnh",
        "Smoke": "Khói",
        "Dust": "Bụi",
        "Sandstorm": "Bão cát",
        "Blizzard": "Bão tuyết",
        "Tornado": "Lốc xoáy",
        "Hurricane": "Bão nhiệt đới",
        "Cold": "Lạnh",
        "Hot": "Nóng",
        "Showers": "Mưa rào", // Added
        "Thunder": "Sấm sét" // Added
    };

    if (!condition) return 'Không xác định';

    // Xử lý các điều kiện phức tạp hơn
    const conditions = condition.split(',').map(c => c.trim());
    const translated = conditions.map(c => translations[c] || c);

    // Ưu tiên hiển thị các điều kiện quan trọng hơn (Mưa, Giông > Mây)
    if (translated.includes("Có mưa") || translated.includes("Mưa rào")) return translated.filter(t => t.includes("mưa") || t.includes("Mưa")).join(', ');
    if (translated.includes("Giông bão")) return "Giông bão";
    if (translated.includes("Có tuyết")) return "Có tuyết";

    return translated.join(', '); // Trả về bản dịch hoặc giữ nguyên nếu không có
}

/**
 * Cập nhật toàn bộ giao diện người dùng với dữ liệu thời tiết mới nhất.
 */
function updateUI() {
    updateDaySelectionUI(); // Làm nổi bật ngày được chọn

    // Kiểm tra dữ liệu có hợp lệ không
    if (!weatherData || !weatherData.days || weatherData.days.length <= selectedDayIndex) {
        // Xác định thông báo lỗi phù hợp
        const errorText = (
            weatherConditionElement.textContent.includes('Lỗi') ||
            weatherConditionElement.textContent.includes('thất bại') ||
            weatherConditionElement.textContent.includes('Đang tải') ||
            weatherConditionElement.textContent.includes('Cần')
        ) ? weatherConditionElement.textContent : 'Không có dữ liệu';

        // Reset các thành phần UI về trạng thái trống/lỗi
        weatherConditionElement.textContent = errorText;
        headerDayNameElement.textContent = "Thời tiết"; // Tiêu đề mặc định
        currentTempElement.textContent = '--';
        humidityElement.textContent = '--%';
        pressureElement.textContent = '-- hPa';
        visibilityElement.textContent = '-- km';
        cloudcoverElement.textContent = '--%';
        solarenergyElement.textContent = '-- W/m²';
        windSpeedElement.textContent = `-- ${userSettings.units === 'metric' ? 'km/h' : 'mph'}`;
        windDirectionElement.textContent = '--°';
        sunriseTimeElement.textContent = '--:--';
        sunsetTimeElement.textContent = '--:--';
        feelsLikeTempElement.textContent = '--°';
        feelsLikeTempMinElement.textContent = '↓ --°';
        feelsLikeTempMaxElement.textContent = '↑ --°';
        tempHighElement.textContent = 'Cao nhất↑ --°';
        tempLowElement.textContent = 'Thấp nhất↓ --°';
        uvindexElement.textContent = '--';
        uvindexContainerElement.className = 'uvindex'; 
        alertNoneImage.style.display = 'none'; 
        alertNoneImage.src = '';
        alertNoneImage.alt = '';
        weatherAlertElement.classList.add('hidden'); 

        updateAirQualityDisplay(); // Cập nhật AQ (sẽ hiển thị '--')
        updateForecastDisplayStatic(); // Cập nhật dự báo 7 ngày (sẽ hiển thị '--')
        checkAndDisplayReminder(); // Cập nhật nhắc nhở (sẽ trống)

        // Xóa biểu đồ nếu đang hiển thị
        if (hourlyChart) { hourlyChart.destroy(); hourlyChart = null; }
        // Hiển thị thông báo trên canvas nếu không có dữ liệu
        if (hourlyChartCanvas) {
            const ctx = hourlyChartCanvas.getContext('2d');
            ctx.clearRect(0, 0, hourlyChartCanvas.width, hourlyChartCanvas.height);
            ctx.fillStyle = getComputedStyle(document.body).getPropertyValue('--text-color').trim() || '#333';
            ctx.textAlign = 'center';
            ctx.fillText("Không có dữ liệu hàng giờ.", hourlyChartCanvas.width / 2, 50);
        }
        return; // Dừng thực thi nếu không có dữ liệu
    }

    // Lấy dữ liệu cho ngày được chọn và dữ liệu hiện tại (nếu là ngày hôm nay)
    const dayData = weatherData.days[selectedDayIndex];
    const currentConditions = (selectedDayIndex === 0 && weatherData.currentConditions) ? weatherData.currentConditions : dayData; // Use dayData as fallback if current not available

    // Cập nhật tên ngày và điều kiện thời tiết
    headerDayNameElement.textContent = (selectedDayIndex === 0)
        ? 'Hôm nay'
        : getDayName(new Date(dayData.datetimeEpoch * 1000));
    weatherConditionElement.textContent = translateWeatherCondition(dayData.conditions || currentConditions.conditions);

    updateTemperatureDisplay(); // Cập nhật các hiển thị nhiệt độ

    // Cập nhật các chi tiết thời tiết khác
    humidityElement.textContent = `${dayData.humidity ?? '--'}%`;
    pressureElement.textContent = `${currentConditions.pressure ?? '--'} hPa`;
    visibilityElement.textContent = `${currentConditions.visibility ?? '--'} km`;
    cloudcoverElement.textContent = `${currentConditions.cloudcover ?? '--'}%`;
    solarenergyElement.textContent = `${currentConditions.solarenergy ?? '--'} W/m²`;

    const windSpeedValue = currentConditions.windspeed;
    const windSpeedUnit = userSettings.units === 'metric' ? 'km/h' : 'mph';
    windSpeedElement.textContent = (windSpeedValue !== null && typeof windSpeedValue !== 'undefined')
        ? `${Math.round(windSpeedValue)} ${windSpeedUnit}`
        : `-- ${windSpeedUnit}`;
    windDirectionElement.textContent = `${currentConditions.winddir ?? '--'}°`;

    // Cập nhật thời gian mặt trời mọc/lặn
    sunriseTimeElement.textContent = formatTimeFromAPI(dayData.sunrise);
    sunsetTimeElement.textContent = formatTimeFromAPI(dayData.sunset);

    updateAirQualityDisplay(); // Cập nhật hiển thị chất lượng không khí

    // Kiểm tra và hiển thị cảnh báo thời tiết (nếu có)
    if (weatherData.alerts?.length > 0) {
        weatherAlertElement.classList.remove('hidden');
        weatherAlertElement.title = weatherData.alerts
            .map(a => a.headline || a.event || 'Cảnh báo thời tiết') // Use headline if available
            .join('; ');
    } else {
        weatherAlertElement.classList.add('hidden');
        weatherAlertElement.title = '';
    }

    updateForecastDisplayStatic(); // Cập nhật dự báo 7 ngày (không gồm chart)
    checkAndDisplayReminder(); // Cập nhật nhắc nhở

    // Vẽ lại biểu đồ nếu accordion đang mở
    const hourlyContent = document.getElementById('hourly-forecast-content');
    if (hourlyContent?.classList.contains('active')) {
        renderHourlyChart(); // Render chart 24h tới
    }
}


/**
 * Cập nhật các phần tử hiển thị nhiệt độ trên giao diện.
 */
function updateTemperatureDisplay() {
    // Kiểm tra dữ liệu ngày được chọn
    if (!weatherData?.days?.[selectedDayIndex]) return;

    const dayData = weatherData.days[selectedDayIndex];
    // Sử dụng currentConditions nếu là ngày hôm nay, nếu không dùng dayData
    const currentConditions = (selectedDayIndex === 0 && weatherData.currentConditions) ? weatherData.currentConditions : dayData;
    const unitSymbol = userSettings.units === 'metric' ? '°C' : '°F';

    // Nhiệt độ hiện tại (hoặc nhiệt độ trung bình của ngày nếu không phải hôm nay)
    currentTempElement.textContent = Math.round(currentConditions.temp ?? dayData.temp);

    // Cảm giác như
    feelsLikeTempElement.textContent = `${Math.round(currentConditions.feelslike ?? dayData.feelslike)}${unitSymbol}`;
    feelsLikeTempMinElement.textContent = `↓ ${Math.round(dayData.feelslikemin)}${unitSymbol}`;
    feelsLikeTempMaxElement.textContent = `↑ ${Math.round(dayData.feelslikemax)}${unitSymbol}`;

    // Nhiệt độ cao/thấp nhất trong ngày
    tempHighElement.textContent = `Cao nhất ↑ ${Math.round(dayData.tempmax)}${unitSymbol}`;
    tempLowElement.textContent = `Thấp nhất ↓ ${Math.round(dayData.tempmin)}${unitSymbol}`;

    // Chỉ số UV
    const uvindexValue = currentConditions.uvindex;
    uvindexElement.textContent = uvindexValue ?? '--';
    uvindexContainerElement.className = 'uvindex'; // Reset lớp CSS
    alertNoneImage.style.display = 'none'; // Mặc định ẩn ảnh cảnh báo
    alertNoneImage.src = '';
    alertNoneImage.alt = '';

    // Áp dụng lớp CSS và hiển thị ảnh cảnh báo dựa trên giá trị UV
    if (uvindexValue !== null && typeof uvindexValue !== 'undefined') {
        if (uvindexValue <= 2) {
            uvindexContainerElement.classList.add('uv-low');
        } else if (uvindexValue <= 5) {
            uvindexContainerElement.classList.add('uv-moderate');
        } else if (uvindexValue <= 7) {
            uvindexContainerElement.classList.add('uv-high'); // Thêm high cho 6-7
        } else if (uvindexValue <= 10) {
            uvindexContainerElement.classList.add('uv-very-high'); // Thêm very-high cho 8-10
            alertNoneImage.src = 'image/alert.png'; // Hiển thị cảnh báo
            alertNoneImage.alt = 'Cảnh báo UV rất cao';
            alertNoneImage.style.display = 'inline-block';
        } else { // UV > 10
            uvindexContainerElement.classList.add('uv-extreme'); // Thêm extreme cho >10
            alertNoneImage.src = 'image/alert.png'; // Hiển thị cảnh báo
            alertNoneImage.alt = 'Cảnh báo UV cực đoan';
            alertNoneImage.style.display = 'inline-block';
        }
    }
}


/**
 * Cập nhật phần hiển thị dự báo 7 ngày (các label, icon, nhiệt độ, thanh bar).
 * Không bao gồm biểu đồ chi tiết hàng giờ.
 */
function updateForecastDisplayStatic() {
    // Kiểm tra dữ liệu
    if (!weatherData || !weatherData.days) return;

    const forecastDays = weatherData.days.slice(0, 7); // Lấy tối đa 7 ngày

    // Tìm nhiệt độ min/max tổng thể trong 7 ngày để tính tỉ lệ thanh bar
    let overallMinTemp = Infinity;
    let overallMaxTemp = -Infinity;
    forecastDays.forEach(day => {
        if (day?.tempmin != null) overallMinTemp = Math.min(overallMinTemp, day.tempmin);
        if (day?.tempmax != null) overallMaxTemp = Math.max(overallMaxTemp, day.tempmax);
    });
    // Xử lý trường hợp không tìm thấy min/max (dữ liệu lỗi)
    if (overallMinTemp === Infinity) overallMinTemp = 0;
    if (overallMaxTemp === -Infinity) overallMaxTemp = 30; // Giá trị mặc định hợp lý
    const overallTempRange = Math.max(1, overallMaxTemp - overallMinTemp); // Tránh chia cho 0

    // Lặp qua 7 vị trí hiển thị
    for (let displayIndex = 0; displayIndex < 7; displayIndex++) {
        const dayData = forecastDays[displayIndex]; // Dữ liệu cho ngày tương ứng

        // Lấy các element DOM cho ngày này
        const dayLabelElement = document.getElementById(`day-${displayIndex}`);
        const iconElement = document.getElementById(`icon-${displayIndex}`);
        const highTempElement = document.getElementById(`high-${displayIndex}`);
        const lowTempElement = document.getElementById(`low-${displayIndex}`);
        const barFillElement = document.getElementById(`bar-${displayIndex}`)?.querySelector('.bar-fill'); // An toàn hơn

        if (dayData && barFillElement) { // Nếu có dữ liệu và element tồn tại
            const date = new Date(dayData.datetimeEpoch * 1000);
            const dayOfWeek = (displayIndex === 0) ? 'Hôm nay' : getDayOfWeek(date);
            const dayMinTemp = dayData.tempmin;
            const dayMaxTemp = dayData.tempmax;

            // Cập nhật text và icon
            dayLabelElement.textContent = dayOfWeek;
            dayLabelElement.dataset.index = displayIndex; // Đặt data-index để xử lý click
            iconElement.innerHTML = `<img src="${getWeatherIconUrl(dayData.icon)}" alt="${dayData.conditions || ''}">`;
            highTempElement.textContent = `${Math.round(dayMaxTemp)}°`;
            lowTempElement.textContent = `${Math.round(dayMinTemp)}°`;

            // Tính toán và cập nhật thanh nhiệt độ
            const dayRange = dayMaxTemp - dayMinTemp;
            const barHeightPercent = Math.max(0, (dayRange / overallTempRange) * 100);
            const barOffsetPercent = Math.max(0, ((dayMinTemp - overallMinTemp) / overallTempRange) * 100);

            barFillElement.style.height = `${barHeightPercent}%`;
            barFillElement.style.bottom = `${barOffsetPercent}%`;
            barFillElement.style.display = 'block'; // Hiển thị thanh bar
        } else { // Nếu không có dữ liệu cho ngày này hoặc element không tồn tại
            dayLabelElement.textContent = '---';
            dayLabelElement.dataset.index = ''; // Xóa data-index
            iconElement.innerHTML = `<img src="image/loading.png" alt="N/A">`; // Icon mặc định
            highTempElement.textContent = '--°';
            lowTempElement.textContent = '--°';
            if (barFillElement) { // Reset thanh bar nếu element tồn tại
                barFillElement.style.height = '0%';
                barFillElement.style.bottom = '0%';
                barFillElement.style.display = 'none'; // Ẩn thanh bar
            }
        }
    }
    updateDaySelectionUI(); // Cập nhật lại trạng thái selected cho ngày
}


/**
 * Định dạng thời gian từ chuỗi API (HH:MM:SS) thành HH:MM.
 * @param {string} timeString - Chuỗi thời gian từ API.
 * @returns {string} - Thời gian định dạng HH:MM hoặc '--:--'.
 */
function formatTimeFromAPI(timeString) {
    if (!timeString || typeof timeString !== 'string') {
        return '--:--';
    }
    const parts = timeString.split(':');
    // Chỉ lấy giờ và phút
    return parts.length >= 2 ? `${parts[0]}:${parts[1]}` : timeString;
}

/**
 * Cập nhật hiển thị thông tin chất lượng không khí.
 */
function updateAirQualityDisplay() {
    // Map key dữ liệu với element ID và đơn vị
    const aqElements = {
        pm1: pm1Element, pm2p5: pm2p5Element, pm10: pm10Element,
        so2: so2Element, no2: no2Element, o3: o3Element, co: coElement,
        aqius: aqiusElement, aqieur: aqieurElement
    };
    const aqUnits = {
        pm1: 'μg/m³', pm2p5: 'μg/m³', pm10: 'μg/m³',
        so2: 'μg/m³', no2: 'μg/m³', o3: 'μg/m³', co: 'μg/m³',
        aqius: '', aqieur: ''
    };
    // Ngưỡng AQI (tham khảo, có thể điều chỉnh)
    const aqThresholds = {
        pm1: { good: 12, moderate: 35.4, unhealthy_sens: 55.4, unhealthy: 150.4, very_unhealthy: 250.4 },
        pm2p5: { good: 12, moderate: 35.4, unhealthy_sens: 55.4, unhealthy: 150.4, very_unhealthy: 250.4 },
        pm10: { good: 54, moderate: 154, unhealthy_sens: 254, unhealthy: 354, very_unhealthy: 424 },
        aqius: { good: 50, moderate: 100, unhealthy_sens: 150, unhealthy: 200, very_unhealthy: 300 },
        aqieur: { good: 20, moderate: 40, unhealthy_sens: 60, unhealthy: 80, very_unhealthy: 100 }, // EU CAQI ranges ~
        o3: { good: 100, moderate: 160, unhealthy_sens: 214, unhealthy: 267, very_unhealthy: 748 }, // Adjusted based on μg/m³
        no2: { good: 40, moderate: 90, unhealthy_sens: 120, unhealthy: 230, very_unhealthy: 340 }, // Adjusted
        so2: { good: 40, moderate: 80, unhealthy_sens: 380, unhealthy: 500, very_unhealthy: 750 }, // Adjusted
        co: { good: 4400, moderate: 9400, unhealthy_sens: 12400, unhealthy: 15400, very_unhealthy: 30400 } // Based on ppm conversion approx
    };
    // Số chữ số thập phân muốn hiển thị
    const aqPrecision = {
        pm1: 1, pm2p5: 1, pm10: 0, so2: 1, no2: 1, o3: 1, co: 0, aqius: 0, aqieur: 0
    };
    // Lấy dữ liệu AQ hiện tại (nếu có)
    const aqConditions = airQualityData?.currentConditions;

    // Hàm tiện ích để đặt giá trị và màu sắc cho element AQ
    const setAirQualityValue = (element, value, unit = '', thresholds = null, precision = 0) => {
        if (!element) return; // Thoát nếu element không tồn tại

        if (value === null || typeof value === 'undefined') {
            element.textContent = `-- ${unit}`.trim();
            element.style.color = 'var(--text-color)';
            element.style.opacity = '0.6'; // Làm mờ đi
        } else {
            const numericValue = Number(value);
            element.textContent = `${numericValue.toFixed(precision)} ${unit}`.trim();
            element.style.opacity = '1';
            // Đặt màu dựa trên ngưỡng
            if (thresholds) {
                if (numericValue <= thresholds.good) element.style.color = '#4caf50'; // Green - Tốt
                else if (numericValue <= thresholds.moderate) element.style.color = '#ffeb3b'; // Yellow - Trung bình
                else if (numericValue <= thresholds.unhealthy_sens) element.style.color = '#ff9800'; // Orange - Kém (nhóm nhạy cảm)
                else if (numericValue <= thresholds.unhealthy) element.style.color = '#f44336'; // Red - Xấu
                else if (numericValue <= thresholds.very_unhealthy) element.style.color = '#9c27b0'; // Purple - Rất xấu
                else element.style.color = '#795548'; // Maroon/Brown - Nguy hại
            } else {
                element.style.color = 'var(--text-color)'; // Màu mặc định nếu không có ngưỡng
            }
        }
    };

    // Lặp qua các chỉ số AQ và cập nhật element tương ứng
    for (const key in aqElements) {
        if (Object.hasOwnProperty.call(aqElements, key)) {
            setAirQualityValue(
                aqElements[key],
                aqConditions?.[key], // Lấy giá trị từ dữ liệu AQ
                aqUnits[key],
                aqThresholds[key],
                aqPrecision[key]
            );
        }
    }
}

/**
 * Vẽ hoặc cập nhật biểu đồ dự báo hàng giờ cho 24 giờ tới.
 */
async function renderHourlyChart() {
    // Kiểm tra dữ liệu và canvas
    if (!weatherData?.days?.[0]?.hours || !hourlyChartCanvas) {
        console.error("Dữ liệu hàng giờ cho hôm nay hoặc canvas không khả dụng.");
        if (hourlyChart) hourlyChart.destroy(); hourlyChart = null;
        if (hourlyChartCanvas) {
            // Hiển thị thông báo lỗi trên canvas
            const ctx = hourlyChartCanvas.getContext('2d');
            ctx.clearRect(0, 0, hourlyChartCanvas.width, hourlyChartCanvas.height);
            const bodyStyle = getComputedStyle(document.body);
            ctx.fillStyle = bodyStyle.getPropertyValue('--text-color').trim() || '#333';
            ctx.textAlign = 'center';
            ctx.fillText("Không có dữ liệu hàng giờ.", hourlyChartCanvas.width / 2, 50);
        }
        return;
    }

    const nowEpoch = Math.floor(Date.now() / 1000);
    const hoursToday = weatherData.days[0].hours;
    const hoursTomorrow = weatherData.days[1]?.hours || []; // Lấy dữ liệu ngày mai nếu có

    const allHours = [...hoursToday, ...hoursTomorrow]; // Kết hợp dữ liệu 2 ngày

    // Tìm index của giờ hiện tại hoặc giờ gần nhất trong quá khứ
    let currentHourIndex = allHours.findIndex(h => h.datetimeEpoch >= nowEpoch);
    if (currentHourIndex === -1) { // Nếu không tìm thấy giờ tương lai (hiếm), lấy giờ cuối cùng
         currentHourIndex = hoursToday.length > 0 ? hoursToday.length - 1 : 0;
         console.warn("Không tìm thấy giờ hiện tại trong dữ liệu, hiển thị từ giờ cuối cùng của hôm nay.");
    } else if (currentHourIndex > 0 && allHours[currentHourIndex].datetimeEpoch > nowEpoch) {
         // Nếu giờ đầu tiên tìm được là trong tương lai, lùi lại 1 giờ để bắt đầu từ giờ quá khứ gần nhất
         currentHourIndex--;
    }


    const next24HoursData = allHours.slice(currentHourIndex, currentHourIndex + 24);

    const labels = [];
    const temperatures = [];
    const icons = [];

    // Chuẩn bị dữ liệu cho 24 giờ tới
    next24HoursData.forEach(hourEntry => {
        if (hourEntry) {
            const hour = new Date(hourEntry.datetimeEpoch * 1000).getHours();
            labels.push(`${hour.toString().padStart(2, '0')}:00`); // Nhãn giờ (VD: "14:00")
            temperatures.push(hourEntry.temp); // Nhiệt độ
            const img = new Image();
            img.src = getWeatherIconUrl(hourEntry.icon); // Lấy URL icon
            icons.push(img); // Thêm đối tượng Image
        } else {
            // Xử lý trường hợp thiếu dữ liệu (ít xảy ra với 24h tới)
            const lastLabel = labels.length > 0 ? labels[labels.length - 1] : "00:00";
            const nextHour = (parseInt(lastLabel.split(':')[0], 10) + 1) % 24;
            labels.push(`${nextHour.toString().padStart(2, '0')}:00`);
            temperatures.push(null); // Đánh dấu dữ liệu thiếu
            icons.push(new Image()); // Icon trống
        }
    });

     // Đảm bảo có đúng 24 nhãn nếu next24HoursData < 24
     while(labels.length < 24 && temperatures.length > 0) {
         const lastLabel = labels[labels.length - 1];
         const nextHour = (parseInt(lastLabel.split(':')[0], 10) + 1) % 24;
         labels.push(`${nextHour.toString().padStart(2, '0')}:00`);
         temperatures.push(null);
         icons.push(new Image());
     }


    try {
        await Promise.all(icons.map(img => {
            if (img.complete || !img.src) return Promise.resolve(); // Bỏ qua nếu đã tải hoặc không có src
            return new Promise((resolve, reject) => {
                img.onload = resolve;
                img.onerror = () => {
                    console.warn(`Icon lỗi tải: ${img.src}`);
                    resolve(); // Vẫn resolve để không chặn chart render
                };
                // Thêm timeout nếu cần thiết
                // setTimeout(() => reject(new Error(`Icon timed out: ${img.src}`)), 5000);
            });
        }));
    } catch (error) {
        console.error("Lỗi tải trước icon:", error);
        // Có thể tiếp tục render chart mà không có icon hoặc hiển thị thông báo lỗi
    }

    const ctx = hourlyChartCanvas.getContext('2d');
    const unitSuffix = userSettings.units === 'metric' ? '°C' : '°F';
    const bodyStyle = getComputedStyle(document.body);
    const primaryColor = bodyStyle.getPropertyValue('--primary-color').trim() || '#36b6e5';
    const textColor = bodyStyle.getPropertyValue('--text-color').trim() || '#333';
    const gridColor = (bodyStyle.getPropertyValue('--border-color').trim() || '#e0e0e0'); // Màu lưới + alpha

    // Hủy biểu đồ cũ trước khi tạo mới
    if (hourlyChart) { hourlyChart.destroy(); hourlyChart = null; }

    // Tạo biểu đồ Chart.js mới
    hourlyChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels, // Nhãn 24 giờ tới
            datasets: [{
                label: `Nhiệt độ (${unitSuffix})`,
                data: temperatures, // Dữ liệu nhiệt độ 24 giờ tới
                borderColor: primaryColor,
                backgroundColor: primaryColor + '33',
                tension: 0.3,
                fill: false,
                pointRadius: 0, // Ẩn điểm mặc định
                pointHoverRadius: 5,
                pointBackgroundColor: primaryColor,
                icons: icons, // Truyền mảng icon đã tải
                unitSuffix: unitSuffix,
                segment: { // Vẽ đường đứt nét nếu có dữ liệu null
                    borderColor: ctx => (temperatures[ctx.p0DataIndex] === null || temperatures[ctx.p1DataIndex] === null) ? gridColor : primaryColor,
                    borderDash: ctx => (temperatures[ctx.p0DataIndex] === null || temperatures[ctx.p1DataIndex] === null) ? [6, 6] : undefined,
                },
                spanGaps: false // Không nối qua các điểm null
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            layout: {
                padding: { top: 10, bottom: -5, } // Tăng padding dưới để có chỗ cho text nhiệt độ
            },
            plugins: {
                hourlyIcons: { // Cấu hình plugin vẽ icon/temp
                    iconSize: 22,       // Kích thước icon
                    paddingTop: 5,
                    iconTopMargin: -2,  // Dịch chuyển icon lên trên
                    textYOffset: 7,    // Khoảng cách text nhiệt độ dưới icon 
                    textColor: textColor,
                    textFont: '11px Roboto'
                },
                legend: {
                    display: false // Ẩn chú thích mặc định
                },
                tooltip: { // Cấu hình tooltip khi hover
                    callbacks: {
                        title: (tooltipItems) => tooltipItems[0].label, // Hiển thị giờ làm tiêu đề
                        label: (tooltipItem) => {
                            let label = 'Nhiệt độ: ';
                            if (tooltipItem.parsed.y !== null) {
                                label += `${tooltipItem.parsed.y.toFixed(1)} ${unitSuffix}`;
                            } else {
                                label += 'Không có dữ liệu';
                            }
                            // Có thể thêm thông tin khác ở đây nếu cần
                            return label;
                        }
                    },
                    bodyColor: textColor,
                    titleColor: textColor,
                    backgroundColor: bodyStyle.getPropertyValue('--card-color').trim() || '#fff',
                    borderColor: primaryColor,
                    borderWidth: 1,
                    padding: 5,
                    displayColors: false // Không hiển thị ô màu nhỏ trong tooltip
                }
            },
            scales: {
                x: { // Trục X (giờ)
                    title: { display: true },
                    ticks: {
                        color: textColor,
                        maxRotation: 0,
                        autoSkip: true, // Cho phép bỏ qua nhãn nếu quá dày
                        maxTicksLimit: 24, // Giới hạn số lượng nhãn hiển thị
                        font: { size: 12 }
                    },
                    grid: {
                         color: gridColor,
                    }
                },
                y: { // Trục Y (nhiệt độ)
                    display: true, // Ẩn hoàn toàn trục Y (vì đã có text nhiệt độ trên chart)
                    title: { display: false },
                    ticks: {
                        color: textColor,
                        padding: 10,
                        callback: (value) => Math.round(value) + unitSuffix,
                        stepSize: 5 // Có thể điều chỉnh bước nhảy nếu cần
                    },
                    grid: {
                        color: gridColor,
                    },
                    beginAtZero: false // Không bắt đầu từ 0
                }
            },
            interaction: {
                intersect: false, // Tooltip hiển thị khi hover gần điểm
                mode: 'index' // Tooltip hiển thị cho tất cả dataset tại một index
            }
        }
    });
}

/**
 * Kiểm tra điều kiện thời tiết vào thời gian nhắc nhở và hiển thị thông báo.
 */
function checkAndDisplayReminder() {
    const reminderTime = userSettings.reminderTime;
    const reminderContainer = reminderMessageContainer;
    const reminderElement = reminderMessageElement;

    if (!reminderTime || !weatherData || !weatherData.days || !reminderContainer || !reminderElement) {
        if(reminderElement) reminderElement.textContent = ''; // Xóa tin nhắn cũ nếu không đủ điều kiện
        if(reminderContainer) reminderContainer.classList.add('hidden');
        return;
    }

    const [reminderHour, reminderMinute] = reminderTime.split(':').map(Number);

    if (isNaN(reminderHour) || isNaN(reminderMinute)) {
        reminderElement.textContent = 'Thời gian nhắc nhở không hợp lệ.';
        reminderContainer.classList.remove('hidden');
        return;
    }

    const now = new Date();
    let reminderDateTime = new Date();
    reminderDateTime.setHours(reminderHour, reminderMinute, 0, 0);

    // Nếu thời gian nhắc nhở đã qua trong ngày hôm nay, đặt nó cho ngày mai
    if (reminderDateTime <= now) {
        reminderDateTime.setDate(reminderDateTime.getDate() + 1);
    }

    const reminderEpoch = Math.floor(reminderDateTime.getTime() / 1000);

    // Tìm dữ liệu giờ gần nhất với thời gian nhắc nhở (trong vòng 1 giờ tới)
    let targetHourData = null;
    const allHours = [...(weatherData.days[0]?.hours || []), ...(weatherData.days[1]?.hours || [])];

    for (const hourData of allHours) {
        if (hourData.datetimeEpoch >= reminderEpoch) {
            // Lấy giờ đầu tiên >= thời gian nhắc nhở
            targetHourData = hourData;
            break;
        }
         // Nếu không có giờ nào >=, lấy giờ cuối cùng có thể (dự phòng)
         targetHourData = hourData;
    }


    if (!targetHourData) {
        reminderElement.textContent = `Không tìm thấy dự báo cho ${reminderTime}.`;
        reminderContainer.classList.remove('hidden');
        return;
    }

    // Kiểm tra điều kiện
    const willRain = (targetHourData.preciptype?.includes('rain')) || targetHourData.precip > 0.1; // Ngưỡng mưa nhỏ
    const isUvHigh = targetHourData.uvindex >= 6; // Ngưỡng UV cao (có thể điều chỉnh)
    let message = '';

    if (willRain) {
        message = `⚠️ Dự báo có mưa vào ${reminderTime}. Nhớ mang theo ô/áo mưa nhé bạn!`;
    } else if (isUvHigh) {
        message = `☀️ Chỉ số UV cao (${targetHourData.uvindex}) vào ${reminderTime}. Hãy mặc áo khoác và bảo vệ da nhé!`;
    } else {
        message = `😊 Thời tiết ${reminderTime} dự báo tốt. Chúc bạn một ngày vui vẻ và làm việc năng suất!`;
    }

    reminderElement.textContent = message;
    reminderContainer.classList.remove('hidden'); // Hiển thị container
}


/**
 * Cập nhật badge trên icon của extension với nhiệt độ hiện tại.
 */
function updateBadge() {
    // Kiểm tra xem có nên hiển thị badge và có dữ liệu không
    if (!userSettings.showBadge || !weatherData?.currentConditions) {
        clearBadge(); // Xóa badge nếu không đủ điều kiện
        return;
    }
    // Lấy nhiệt độ hiện tại và làm tròn
    const temp = Math.round(weatherData.currentConditions.temp);
    // Lấy ký hiệu đơn vị
    const unitSuffix = userSettings.units === 'metric' ? 'C' : 'F';
    const tempText = `${temp}°${unitSuffix}`; // Tạo text cho badge

    // Cập nhật badge bằng chrome.action API
    if (chrome.action) {
        chrome.action.setBadgeText({ text: tempText });
        chrome.action.setBadgeBackgroundColor({ color: '#36b6e5' }); // Màu nền badge
    } else {
        console.warn("API chrome.action không khả dụng."); // Cảnh báo nếu API không có
    }
}

/**
 * Xóa text và màu nền của badge trên icon extension.
 */
function clearBadge() {
    if (chrome.action) {
        chrome.action.setBadgeText({ text: '' }); // Đặt text rỗng
    }
}

/**
 * Lấy tên viết tắt của thứ trong tuần từ đối tượng Date (theo locale vi-VN).
 * @param {Date} date - Đối tượng Date.
 * @returns {string} - Tên viết tắt của thứ (ví dụ: 'Th 2').
 */
function getDayOfWeek(date) {
    if (!(date instanceof Date) || isNaN(date)) return '---'; // Trả về '---' nếu date không hợp lệ
    return date.toLocaleDateString('vi-VN', { weekday: 'short' });
}

/**
 * Lấy tên đầy đủ của ngày trong tuần từ đối tượng Date (theo locale vi-VN).
 * @param {Date} date - Đối tượng Date.
 * @returns {string} - Tên đầy đủ của ngày (ví dụ: 'Thứ Hai').
 */
function getDayName(date) {
    if (!(date instanceof Date) || isNaN(date)) return 'Ngày đã chọn'; // Trả về text mặc định nếu date không hợp lệ
    return date.toLocaleDateString('vi-VN', { weekday: 'long' });
}

/**
 * Lấy đường dẫn URL của icon thời tiết dựa trên mã icon từ API.
 * @param {string} icon - Mã icon từ API Visual Crossing.
 * @returns {string} - Đường dẫn đến file ảnh icon tương ứng.
 */
function getWeatherIconUrl(icon) {
    // Mapping từ mã icon API sang tên file ảnh
    const iconMap = {
        'clear-day': 'image/clear-day.png',
        'clear-night': 'image/clear-night.png',
        'partly-cloudy-day': 'image/partly-cloudy-day.png',
        'partly-cloudy-night': 'image/partly-cloudy-night.png',
        'cloudy': 'image/cloudy.png',
        'rain': 'image/rain.png',
        'snow': 'image/snow.png',
        'sleet': 'image/sleet.png', // Mưa tuyết
        'wind': 'image/wind.png',
        'fog': 'image/fog.png',
        'rain-snow': 'image/sleet.png', // Alias
        'rain-snow-showers-day': 'image/sleet.png', // Alias
        'rain-snow-showers-night': 'image/sleet.png', // Alias
        'showers-day': 'image/rain.png', // Mưa rào ban ngày
        'showers-night': 'image/rain.png', // Mưa rào ban đêm
        'snow-showers-day': 'image/snow.png', // Tuyết rơi ban ngày
        'snow-showers-night': 'image/snow.png', // Tuyết rơi ban đêm
        'thunder-rain': 'image/thunderstorm.png', // Mưa giông
        'thunder-showers-day': 'image/thunderstorm.png', // Mưa giông ban ngày
        'thunder-showers-night': 'image/thunderstorm.png', // Mưa giông ban đêm
        'thunder': 'image/thunderstorm.png' // Chỉ có sấm sét
    };
    return iconMap[icon] || 'image/loading.png';
}