// Background service worker for the Weatherly extension

// Global variables for storing data
let weatherData = null;
let userSettings = null;
let lastFetchTime = 0;
const REFRESH_INTERVAL = 30 * 60 * 1000; // 30 minutes in milliseconds

// Initialize the background service worker
chrome.runtime.onInstalled.addListener(() => {
  console.log('Weatherly extension installed');
  loadSettings();
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'getWeatherData') {
    // Send cached weather data if available and recent
    if (weatherData && (Date.now() - lastFetchTime < REFRESH_INTERVAL)) {
      sendResponse({ data: weatherData });
    } else {
      // Data is stale or not available, fetch new data
      fetchWeatherData()
        .then(data => {
          sendResponse({ data });
        })
        .catch(error => {
          sendResponse({ error: error.message });
        });
      return true; // This keeps the message channel open for the async response
    }
  } else if (message.action === 'updateSettings') {
    userSettings = message.settings;
    saveSettings();

    // Update badge if needed
    if (weatherData) {
      updateBadge();
    }

    sendResponse({ success: true });
  }
});

// Load user settings from storage
function loadSettings() {
  chrome.storage.sync.get(['userSettings'], (result) => {
    if (result.userSettings) {
      userSettings = result.userSettings;

      // Fetch weather data once settings are loaded
      fetchWeatherData()
        .then(data => {
          if (userSettings.showBadge) {
            updateBadge();
          }
        })
        .catch(error => {
          console.error('Error fetching weather data:', error);
        });
    } else {
      // Default settings if none found
      userSettings = {
        apiKey: 'ELBNC7KRNHRYQ8KLL4N7E6H23',
        units: 'metric',
        darkMode: false,
        showBadge: true,
        language: 'en'
      };
      saveSettings();
    }
  });
}

// Save user settings to storage
function saveSettings() {
  chrome.storage.sync.set({ userSettings }, () => {
    console.log('Settings saved');
  });
}

// Update the extension badge with current temperature
function updateBadge() {
  if (!weatherData || !userSettings.showBadge) {
    return;
  }

  const temp =  weatherData.currentConditions.temp;
  chrome.action.setBadgeText({ text: temp });
  chrome.action.setBadgeBackgroundColor({ color: '#36b6e5' });
}

// Fetch weather data from Visual Crossing API
function fetchWeatherData() {
  return new Promise((resolve, reject) => {
    // Check if we have an API key
    if (!userSettings || !userSettings.apiKey) {
      reject(new Error('API key not set'));
      return;
    }

    // Get user's location
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;

        // Build API URL
        const url = `https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/${lat},${lon}?unitGroup=metric&include=current,days,hours,alerts&key=${userSettings.apiKey}&contentType=json`;

        // Fetch data
        fetch(url)
          .then(response => {
            if (!response.ok) {
              throw new Error(`Weather API error: ${response.status}`);
            }
            return response.json();
          })
          .then(data => {
            weatherData = data;
            lastFetchTime = Date.now();

            // Schedule next update
            scheduleNextUpdate();

            resolve(data);
          })
          .catch(error => {
            reject(error);
          });
      },
      (error) => {
        reject(new Error('Geolocation error: ' + error.message));
      }
    );
  });
}

// Schedule the next data update
function scheduleNextUpdate() {
  chrome.alarms.create('weatherUpdate', {
    delayInMinutes: REFRESH_INTERVAL / (60 * 1000)
  });
}

// Listen for alarm to update weather data
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'weatherUpdate') {
    fetchWeatherData()
      .then(() => {
        if (userSettings.showBadge) {
          updateBadge();
        }
      })
      .catch(error => {
        console.error('Error updating weather data:', error);
      });
  }
});
